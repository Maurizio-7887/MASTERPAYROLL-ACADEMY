"""Context of one run: the request normalised into rules, chain and schedule.

The context is an immutable record; :mod:`._context_build` resolves it from
the request and :mod:`._context_facts` derives the facts it exposes.

Pure functions of the values a :class:`RunContext` holds, so the context
stays a plain immutable record.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

from ccnl_engine.balance.opening.rules import opening_state_issue
from ccnl_engine.employment.inputs import FixedTerm
from ccnl_engine.employment.spell.models import EmploymentSpell, spells_with
from ccnl_engine.event.facade import AbsenceEvent
from ccnl_engine.pay_item.rounding.policies import money
from ccnl_engine.run.models import RunKind
from ccnl_engine.tax_credit.recovery.models import InstallmentRun
from ccnl_engine.withholding.cap.services import ends_in_year

if TYPE_CHECKING:
    from decimal import Decimal

    from ccnl_engine.balance.models import PeriodState
    from ccnl_engine.calendar.payment.models import PaymentId
    from ccnl_engine.compensation.element.types import (
        ApprenticeshipScaling,
        MonthlyPayChain,
    )
    from ccnl_engine.compensation.proration.services import RunProration
    from ccnl_engine.decision.models import CalculationIssue
    from ccnl_engine.employment.category.models import WorkerCategory
    from ccnl_engine.employment.period.inputs import EmploymentPeriod
    from ccnl_engine.extra_month.models import ExtraMonthAccrual
    from ccnl_engine.pay_item.facade import CompetencePeriod
    from ccnl_engine.pay_item.policies import PolicyContext, PolicyResolver
    from ccnl_engine.period.context.agreement.services import RunContract
    from ccnl_engine.period.ports import KnowledgeRepository
    from ccnl_engine.period.requests import PeriodCalculationRequest
    from ccnl_engine.variable_pay.models import VariablePayRules
    from ccnl_engine.withholding.schedule.models import (
        WithholdingPosition,
        WithholdingSchedule,
    )


__all__ = [
    "chain_gross",
    "installment_run",
    "settles_tax_year",
]


@dataclass(frozen=True)
class RunContext:
    """Normalised inputs of one run, shared by every step of the pipeline.

    Attributes:
        request: The period calculation request.
        repo: Knowledge repository the rules are loaded from.
        resolver: Policy resolver of the pay-item kinds.
        contract: CCNL, level, dates and yearly rules.
        withholding_schedule: Withholding slots of the tax year.
        withholding: Position of the payment in the schedule: the slots it
            leaves unpaid and whether it settles the conguaglio.
        worker_category: Canonical category of the worker.
        chain: Pay chain of the run, adjusted for an extra month or
            prorated for a partly employed month.
        apprenticeship: Percentage scaling of a percentage apprenticeship,
            ``None`` for any other contract or track.
        payment: The payment the calculation closes: its run and date.
        upcoming_gross: Recurring gross of the slots still to come.
        accrual: Rateo an extra-month run pays, ``None`` for a regular run.
        var_pay_rules: Variable pay rules of the tax year.
        policy_context: Context the pay-item policies are resolved in.
        cp: Competence period of the run.
        regular_chain: Pay chain of a fully employed regular month, which
            the extra-month settlements and the domestic hourly rate read.
        proration: Payable part of the month of a regular run.
        settlements: Ratei the run liquidates at the termination of the
            employment, paid as extra-month earnings.
        full_time_chain: Pay chain of a fully employed regular month at full
            time, which the CCNL hourly base divides by its full-time
            divisor.
    """

    request: PeriodCalculationRequest
    repo: KnowledgeRepository
    resolver: PolicyResolver
    contract: RunContract
    withholding_schedule: WithholdingSchedule
    withholding: WithholdingPosition
    worker_category: WorkerCategory | None
    chain: MonthlyPayChain
    apprenticeship: ApprenticeshipScaling | None
    payment: PaymentId
    upcoming_gross: Decimal
    accrual: ExtraMonthAccrual | None
    var_pay_rules: VariablePayRules
    policy_context: PolicyContext
    cp: CompetencePeriod
    regular_chain: MonthlyPayChain
    proration: RunProration
    settlements: tuple[ExtraMonthAccrual, ...]
    full_time_chain: MonthlyPayChain

    @property
    def fiscal_year(self) -> int:
        """Tax year the run belongs to."""
        return self.contract.tctx.fiscal_year

    @property
    def takes_last_slot(self) -> bool:
        """Whether the payment leaves no slot of its tax year unpaid.

        Read by identity from :attr:`withholding`: the runs the tax cash
        state has paid against the payments of the schedule.
        """
        return self.withholding.settles

    @property
    def ytd_inps_base(self) -> Decimal:
        """INPS base of the competence year before the run, all employers."""
        return self.opening.accrual.inps_base(self.cp.year).total

    @property
    def run_kind(self) -> RunKind:
        """Kind of the run."""
        return self.payment.run_id.kind

    @property
    def run_id(self) -> str:
        """Run identifier as the tag of item and entry ids."""
        return str(self.payment.run_id)

    @property
    def installment_run(self) -> InstallmentRun:
        """The run as the credit recoveries see it.

        The run is final when it is a termination run, or when the
        employment ends in the tax year and the run takes its last
        withholding slot: no later payslip can carry an installment.
        """
        return installment_run(
            self.run_kind,
            self.request.employment_period,
            self.fiscal_year,
            takes_last_slot=self.takes_last_slot,
        )

    @property
    def closes_employment(self) -> bool:
        """Whether the run closes the employment.

        A termination run does, and so does the regular run of the month
        the employment ends in; an extra-month or adjustment run of that
        month does not.
        """
        period = self.request.employment_period
        ended = None if period is None else period.ended_on
        month = self.request.period_id
        kind = self.run_kind
        return kind is RunKind.TERMINATION or (
            kind is RunKind.REGULAR
            and ended is not None
            and (ended.year, ended.month) == (month.year, month.month)
        )

    @property
    def conguaglio(self) -> bool:
        """Whether the run settles the tax year.

        It does when it takes the last withholding slot of the year or is
        the last run of the employment (:attr:`installment_run`).
        """
        return settles_tax_year(
            self.installment_run, self.run_kind, takes_last_slot=self.takes_last_slot
        )

    @property
    def opening(self) -> PeriodState:
        """State the run opens with."""
        return self.request.opening_state

    @property
    def opening_issue(self) -> CalculationIssue | None:
        """Issue of an opening state that misses the employment history."""
        period = self.request.employment_period
        return opening_state_issue(
            self.opening,
            self.payment.run_id,
            None if period is None else period.started_on,
            self.request.uncovered_runs,
        )

    @property
    def employment_spells(self) -> tuple[EmploymentSpell, ...]:
        """Employment spells of the tax year after the run.

        The spells the opening state paid in the tax year, with the spell
        of the run's employment in place of the one of its first day: the
        income the withholding projects is the income of every one of them.
        The spell keeps the unpaid days earlier runs recorded and adds those
        of the absences of the run with ``no_pay_due``.
        """
        request = self.request
        opening = self.opening.cash.employment_spells
        spell = EmploymentSpell.of(
            request.employment_period,
            self.fiscal_year,
            fixed_term=isinstance(request.contract_type, FixedTerm),
        )
        earlier = [day for s in opening for day in s.unpaid_days]
        unpaid = [
            day
            for event in request.events
            if isinstance(event, AbsenceEvent) and event.no_pay_due
            for day in event.days
        ]
        # A day of an earlier spell is kept by the spell it falls within.
        merged = None if spell is None else spell.with_unpaid([*earlier, *unpaid])
        return spells_with(opening, merged)

    @property
    def monthly_gross(self) -> Decimal:
        """Gross of the pay chain: base, seniority and allowances."""
        return chain_gross(self.chain)

    @property
    def tfr_pay(self) -> Decimal:
        """TFR base of the pay chain, the excluded allowances left out.

        The gross and the benefits in kind, less the allowances the CCNL
        leaves out of the TFR.
        """
        return (
            self.monthly_gross
            + self.chain.in_kind_total
            - self.chain.tfr_excluded_total
        )

    @property
    def regular_gross(self) -> Decimal:
        """Gross of the pay chain of a fully employed regular month."""
        return chain_gross(self.regular_chain)

    @property
    def withholding_agent(self) -> bool:
        """Whether the employer withholds tax: false for a household employer.

        The only place a run reads it from the CCNL; see
        :mod:`~ccnl_engine.withholding.agent.rules`.
        """
        return self.contract.ccnl.meta.withholding_agent


def installment_run(
    kind: RunKind,
    employment_period: EmploymentPeriod | None,
    fiscal_year: int,
    *,
    takes_last_slot: bool,
) -> InstallmentRun:
    """Return the run as the credit recoveries see it.

    The run is final when it is a termination run, or when the employment
    ends in the tax year and the run takes its last withholding slot: no
    later payslip can carry an installment.

    Returns:
        Whether the run is final and whether it is an adjustment.
    """
    final = kind is RunKind.TERMINATION or (
        ends_in_year(employment_period, fiscal_year) and takes_last_slot
    )
    return InstallmentRun(final=final, adjustment=kind is RunKind.ADJUSTMENT)


def settles_tax_year(
    run: InstallmentRun, kind: RunKind, *, takes_last_slot: bool
) -> bool:
    """Return whether the run settles the tax year (the conguaglio).

    Returns:
        ``True`` when the run takes the last withholding slot of the year
        or is the last run of the employment.
    """
    return run.final or (kind.consumes_withholding_slot and takes_last_slot)


def chain_gross(chain: MonthlyPayChain) -> Decimal:
    """Return the gross of a pay chain: base, seniority and allowances.

    Returns:
        The rounded gross.
    """
    return money(chain.base + chain.seniority + chain.allowances_total)
