"""BundledKnowledgeRepository: reads rules from the package-bundled JSON files."""

from __future__ import annotations

from typing import TYPE_CHECKING

from ccnl_engine.absence.insured.loaders import load_insured_absence_rates
from ccnl_engine.bundle.loaders import bundle_version as _bundle_version
from ccnl_engine.calendar.holiday.loaders import load_national_holidays
from ccnl_engine.capability.loaders import (
    load_capability_catalog,
)
from ccnl_engine.catalog.loaders import list_contracts, load_ccnl
from ccnl_engine.family.loaders import load_family_deduction_rules
from ccnl_engine.limitation.loaders import load_engine_limitations
from ccnl_engine.sector.loaders import load_year_rules
from ccnl_engine.sickness.indemnity.loaders import load_sick_pay_rates
from ccnl_engine.surtax.loaders import load_surtax_rules
from ccnl_engine.variable_pay.loaders import load_variable_pay_rules

if TYPE_CHECKING:
    from ccnl_engine.absence.insured.models import InsuredAbsenceRates
    from ccnl_engine.agreement.facade import CCNL, TaxSector
    from ccnl_engine.calendar.holiday.models import NationalHolidays
    from ccnl_engine.capability.registry.models import CapabilityCatalog
    from ccnl_engine.catalog.loaders import ContractSummary
    from ccnl_engine.family.models import FamilyDeductionRules
    from ccnl_engine.limitation.models import ModelLimitation
    from ccnl_engine.sector.models import YearRules
    from ccnl_engine.sickness.indemnity.models import InpsSickPayRates
    from ccnl_engine.surtax.models import SurtaxRules
    from ccnl_engine.variable_pay.models import VariablePayRules


class BundledKnowledgeRepository:
    """Production implementation of the knowledge repository port.

    Satisfies :class:`~ccnl_engine.period.ports.KnowledgeRepository`. Reads from the
    versioned JSON files bundled inside
    the ``ccnl_engine`` package.  All loader functions are cached, so repeated
    calls for the same arguments return the same (immutable) object without
    re-parsing.
    """

    @property
    def bundle_version(self) -> str:
        """Version of the package-bundled datasets."""
        return _bundle_version()

    def load_contracts(self) -> tuple[ContractSummary, ...]:  # noqa: PLR6301
        """Return the summary of every bundled CCNL, sorted by ``ccnl_id``.

        Returns:
            One summary per bundled CCNL, with its readiness tier.
        """
        return list_contracts()

    def load_ccnl(self, ccnl_id: str) -> CCNL:  # noqa: PLR6301
        """Return the CCNL with slug *ccnl_id* from the bundled data files.

        Returns:
            The validated, immutable CCNL.
        """
        return load_ccnl(ccnl_id)

    def load_year_rules(  # noqa: PLR6301
        self, year: int, sector: TaxSector, num_employees: int
    ) -> YearRules:
        """Return resolved tax year rules for *year*, *sector*, *num_employees*.

        Returns:
            A :class:`~ccnl_engine.sector.models.YearRules` with
            INPS rates resolved for the given headcount.
        """
        return load_year_rules(year, sector, num_employees)

    def load_surtax_rules(self, year: int) -> SurtaxRules:  # noqa: PLR6301
        """Return surtax rules for *year*.

        Returns:
            A :class:`~ccnl_engine.surtax.models.SurtaxRules`
            with regionale and comunale rate tables.
        """
        return load_surtax_rules(year)

    def load_capability_catalog(self, year: int) -> CapabilityCatalog:  # noqa: PLR6301
        """Return the capability catalog for *year*.

        Returns:
            A :class:`~ccnl_engine.capability.registry.models.CapabilityCatalog`
            with all declared capabilities for the requested year.
        """
        return load_capability_catalog(year)

    def load_engine_limitations(self) -> tuple[ModelLimitation, ...]:  # noqa: PLR6301
        """Return the limitations of the engine's shared code paths.

        Returns:
            The engine limitations of the bundle, in file order.
        """
        return load_engine_limitations()

    def load_variable_pay_rules(self, year: int) -> VariablePayRules:  # noqa: PLR6301
        """Return the statutory variable-pay rules for *year*.

        Returns:
            A :class:`~ccnl_engine.variable_pay.models.VariablePayRules`
            with fringe thresholds, PdR and L. 199/2025 regimes.
        """
        return load_variable_pay_rules(year)

    def load_family_deduction_rules(self, year: int) -> FamilyDeductionRules:  # noqa: PLR6301
        """Return the Art. 12 TUIR family deduction rules for *year*.

        Returns:
            A :class:`~ccnl_engine.family.models.FamilyDeductionRules`.
        """
        return load_family_deduction_rules(year)

    def load_sick_pay_rates(self) -> InpsSickPayRates:  # noqa: PLR6301
        """Return the INPS sickness indemnity rules.

        Returns:
            The waiting period, bands, annual maximum and coverage rules.
        """
        return load_sick_pay_rates()

    def load_insured_absence_rates(self) -> InsuredAbsenceRates:  # noqa: PLR6301
        """Return the maternity and work-injury indemnities.

        Returns:
            The INPS maternity indemnity and the work-injury measures.
        """
        return load_insured_absence_rates()

    def load_national_holidays(self) -> NationalHolidays:  # noqa: PLR6301
        """Return the national holidays with civil effects.

        Returns:
            The holidays of L. 260/1949 as amended, besides the Sundays.
        """
        return load_national_holidays()
