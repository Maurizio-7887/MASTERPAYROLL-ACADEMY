"""Result of one period-first payroll calculation."""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass
from datetime import date
from decimal import Decimal
from typing import TYPE_CHECKING

from ccnl_engine.assurance.policies import EngineMode
from ccnl_engine.assurance.rules import assess
from ccnl_engine.balance.models import PeriodState
from ccnl_engine.decision.models import (
    CalculationDecision,
    CalculationIssue,
)
from ccnl_engine.ledger.remittance.models import remittance_summary
from ccnl_engine.period.payslip.line.services import payslip_lines, progressives
from ccnl_engine.run.types import PeriodId

if TYPE_CHECKING:
    from ccnl_engine.assurance.models import ResultAssurance, ResultBlocker
    from ccnl_engine.capability.results import CapabilityReport
    from ccnl_engine.contribution.results import ContributionBreakdown
    from ccnl_engine.extra_month.progress.models import ExtraMonthProgress
    from ccnl_engine.irpef.results import TaxComputation
    from ccnl_engine.leave.balance.models import LeaveBalance
    from ccnl_engine.ledger.models import LedgerEntry
    from ccnl_engine.ledger.remittance.models import RemittanceLine
    from ccnl_engine.limitation.models import ModelLimitation
    from ccnl_engine.pay_item.facade import PayItem
    from ccnl_engine.period.payslip.line.models import PayslipLine, Progressives
    from ccnl_engine.provenance.ruleset.assurance.models import RulesetAssurance
    from ccnl_engine.run.models import PayrollRun
    from ccnl_engine.variable_pay.benefit.results import BenefitBreakdown


@dataclass(frozen=True)
class PeriodResult:
    """Result of one period-first payroll calculation.

    Attributes:
        period_id: The competence period, identical to the request.
        payment_date: Payment date, identical to the request.
        period_gross: Contractual gross entitlement for this period
            (sum of CASH_EARNINGS ledger entries). This is the theoretical
            wage the worker is entitled to before absence deductions.
        period_net: Net pay for this period only.
        period_employer_cost: Employer cost net of unpaid absences:
            ``period_gross - unpaid_absence_deduction + employer_contributions
            + bilateral_fund_employer + tfr_accrual + non_cash_benefits
            + pension_fund_employer + pension_fund_tfr
            + tfr_treasury_fund``.  It leaves out the INAIL premium, which
            rests on the tariff rate of the employer, and IRAP.  It is
            complete within that perimeter only when
            :attr:`is_employer_cost_complete`: an amount the CCNL owes for
            every worker that the engine does not compute (a health fund)
            leaves it short.
        unpaid_absence_deduction: Sum of EMPLOYEE_DEDUCTIONS ledger entries.
            Represents wages not paid due to unpaid absences or sickness.
            Zero when no absences are present.
        closing_state: State after closing this period: the tax year state
            and the obligations.  Pass as ``opening_state`` to the next
            run of the same tax year, or to
            :func:`~ccnl_engine.year.tax_year.closing.rules.close_tax_year` after the
            last run of the year.
        pay_items: All pay items produced for this period.
        ledger_entries: All ledger entries posted for this period.
        contribution_breakdown: Per-component INPS breakdown for audit
            and compliance tracing.
        benefit_breakdown: Per-axis fringe/welfare benefit breakdown for
            audit and cost-centre reporting.
        capability_report: Gaps between the capability catalog and what
            the run executed, with the provenance of the rules each
            capability read and the values the caller supplied.
        issues: Conditions that lower the reliability of this result, in
            the order they were raised.  Empty when every capability
            decided from known rules and facts.
        decisions: What the capabilities that record a decision decided in
            this run, e.g. the eligibility of a pay item for a preferential
            tax regime, in the order they were taken.
        rulesets: Assurance of the rulesets the run read: the CCNL, and
            each tax, INPS and surtax ruleset a payable rule came from, with
            identity, hash, readiness and confidence.
        mode: Payability policy of the engine that produced the result;
            ``operational`` adds a blocker for every ruleset short of
            ``production``, or whose review was due before
            :attr:`payment_date`.
        limitations: Model limitations that concern the run (see
            :class:`~ccnl_engine.limitation.models.ModelLimitation`);
            an open one with a monetary impact blocks the amounts.
        extra_months: Ratei maturati of each extra month by the end of the
            month of a regular or termination run
            (:class:`~ccnl_engine.extra_month.progress.models.ExtraMonthProgress`).

    Whether the amounts can be paid is :attr:`is_payable`: the net pay
    (:attr:`is_net_pay_payable`) and the employer cost
    (:attr:`is_employer_cost_complete`) both reliable.  Why not is
    :attr:`blockers`; all come from :attr:`assurance`.
    """

    period_id: PeriodId
    payment_date: date
    period_gross: Decimal
    period_net: Decimal
    period_employer_cost: Decimal
    closing_state: PeriodState
    pay_items: tuple[PayItem, ...]
    ledger_entries: tuple[LedgerEntry, ...]
    capability_report: CapabilityReport
    contribution_breakdown: ContributionBreakdown
    tax_computation: TaxComputation
    benefit_breakdown: BenefitBreakdown
    run: PayrollRun | None = None
    unpaid_absence_deduction: Decimal = Decimal(0)
    bundle_version: str | None = None
    issues: tuple[CalculationIssue, ...] = ()
    decisions: tuple[CalculationDecision, ...] = ()
    rulesets: tuple[RulesetAssurance, ...] = ()
    mode: EngineMode = EngineMode.SIMULATION
    limitations: tuple[ModelLimitation, ...] = ()
    extra_months: tuple[ExtraMonthProgress, ...] = ()

    @property
    def assurance(self) -> ResultAssurance:
        """Assurance derived from what the run recorded and the mode.

        It is derived on access, so an issue added to the result later
        (e.g. a partial month of a year) is reflected.
        """
        return assess(
            self.issues,
            self.decisions,
            self.capability_report,
            self.rulesets,
            self.mode,
            self.payment_date,
            self.limitations,
        )

    @property
    def leave_balances(self) -> tuple[LeaveBalance, ...]:
        """Leave balances after the run, per bucket and year of accrual.

        Each :class:`~ccnl_engine.leave.balance.models.LeaveBalance` gives
        the days of ferie or the hours of a permit bucket accrued, taken,
        paid and left (``accrued``, ``taken``, ``paid``, ``residual``); they
        are those the closing state carries to the next run.
        """
        return self.closing_state.accrual.leave.balances

    @property
    def paid_gross(self) -> Decimal:
        """Gross actually paid: ``period_gross`` less the unpaid absences.

        ``period_gross`` is the contractual pay of the period with the
        earnings of its events (sick pay included) before the deduction of
        the days not paid; this is what the payslip pays as gross.
        """
        return self.period_gross - self.unpaid_absence_deduction

    def payslip_lines(
        self, voci: Mapping[str, str] | None = None
    ) -> tuple[PayslipLine, ...]:
        """Return the payslip of the run as lines.

        Args:
            voci: The provider's voce code by engine code.

        Returns:
            One line per earning or deduction of the ledger: the competenze
            less the trattenute are :attr:`period_net`.
        """
        return payslip_lines(self, voci)

    @property
    def progressives(self) -> Progressives:
        """The progressivi of the tax year, the INPS base, TFR and ratei."""
        return progressives(self.closing_state, self.period_id.year, self.extra_months)

    @property
    def is_payable(self) -> bool:
        """Whether nothing blocks the amounts of this result."""
        return self.assurance.is_payable

    @property
    def is_net_pay_payable(self) -> bool:
        """Whether no blocker leaves the net pay of this result unreliable."""
        return self.assurance.is_net_pay_payable

    @property
    def is_employer_cost_complete(self) -> bool:
        """Whether no blocker leaves the employer cost of this result short."""
        return self.assurance.is_employer_cost_complete

    @property
    def blockers(self) -> tuple[ResultBlocker, ...]:
        """Every reason the amounts of this result cannot be paid."""
        return self.assurance.blockers

    def remittance_summary(self) -> tuple[RemittanceLine, ...]:
        """Return the tax and credit amounts of the run by F24 codice tributo.

        IRPEF withheld, surtax, substitute and separate taxes, credits paid
        and recovered, IRPEF refunded and recoveries carried for lack of
        pay, one line per account and code (see
        :func:`~ccnl_engine.ledger.remittance.models.remittance_summary`).

        Returns:
            The lines of the run, uncoded ones included.
        """
        return remittance_summary(self.ledger_entries)
