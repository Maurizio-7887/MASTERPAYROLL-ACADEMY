"""Amounts of one run: contributions, taxable, IRPEF and surtax in sequence."""

from __future__ import annotations

from dataclasses import replace
from typing import TYPE_CHECKING

from ccnl_engine.amount.types import _PeriodAmounts
from ccnl_engine.contribution.services import (
    AGRICULTURAL_ZONE_UNKNOWN,
    CIGS_INDOTTO_UNKNOWN,
    FIS_REDUCTION_UNKNOWN,
    run_contributions,
    tfr_accrual,
)
from ccnl_engine.decision.rules import pdr_decision
from ccnl_engine.end_of_service.services import (
    end_of_service_issue,
    life_insurance_issue,
)
from ccnl_engine.fund.assistance.rules import run_assistance
from ccnl_engine.irpef.services import (
    trattamento_issues,
    ulteriore_issues,
    withhold_irpef,
)
from ccnl_engine.irpef.taxable.services import (
    pdr_split,
    taxable_income,
)
from ccnl_engine.pension_fund.services import (
    CONVENTIONAL_BASE_UNKNOWN,
    ERC_UNKNOWN,
    YOUNG_MEMBER_UNKNOWN,
    conventional_base_unknown,
    run_pension,
)
from ccnl_engine.severance.relief.services import (
    with_tfr_compensation,
)
from ccnl_engine.surtax.rules import run_surtax
from ccnl_engine.withholding.agent.services import untaxed_amounts

if TYPE_CHECKING:
    from ccnl_engine.amount.types import _AmountsInput
    from ccnl_engine.contribution.results import ContributionBreakdown
    from ccnl_engine.decision.models import (
        CalculationDecision,
        CalculationIssue,
    )
    from ccnl_engine.irpef.results import TaxComputation
    from ccnl_engine.irpef.services import _Irpef
    from ccnl_engine.irpef.taxable.services import _PdrSplit
    from ccnl_engine.surtax.rules import RunSurtax
    from ccnl_engine.tax_credit.recovery.models import RecoveryPlan


def _decisions(
    inp: _AmountsInput, pdr: _PdrSplit, irpef: _Irpef, surtax: RunSurtax
) -> tuple[CalculationDecision, ...]:
    """Return the tax decisions of the run, the surtax ones last.

    Returns:
        Family deductions, PdR, IRPEF and surtax decisions, when taken.
    """
    return tuple(
        d
        for d in (
            None if irpef.family is None else irpef.family.decision(),
            pdr_decision(
                inp.event_substitute_base,
                pdr.eligible,
                pdr.substitute_tax,
                inp.pdr_rules,
                inp.rules.year,
            ),
            *irpef.tax.decisions,
            *surtax.all_decisions,
        )
        if d is not None
    )


def _issues(inp: _AmountsInput, irpef: _Irpef) -> tuple[CalculationIssue, ...]:
    family = () if irpef.family is None else irpef.family.issues()
    contractual = inp.contractual_fund.issue
    pension = inp.pension
    young = pension is not None and pension.young_member_unknown
    erc = pension is not None and pension.erc_unknown
    conventional = conventional_base_unknown(pension)
    public = end_of_service_issue(inp)
    life = life_insurance_issue(inp)
    fis = inp.rules.inps is not None and inp.rules.inps.fis_reduction_open
    zone = inp.rules.inps is not None and inp.rules.inps.zone_reduction_open
    cigs = inp.rules.inps is not None and inp.rules.inps.cigs_indotto_open
    return (
        family
        + ulteriore_issues(inp, irpef)
        + trattamento_issues(inp, irpef)
        + (() if contractual is None else (contractual,))
        + ((YOUNG_MEMBER_UNKNOWN,) if young else ())
        + ((ERC_UNKNOWN,) if erc else ())
        + ((CONVENTIONAL_BASE_UNKNOWN,) if conventional else ())
        + (() if public is None else (public,))
        + (() if life is None else (life,))
        + ((FIS_REDUCTION_UNKNOWN,) if fis else ())
        + ((AGRICULTURAL_ZONE_UNKNOWN,) if zone else ())
        + ((CIGS_INDOTTO_UNKNOWN,) if cigs else ())
    )


def _compute_amounts(
    inp: _AmountsInput,
) -> tuple[_PeriodAmounts, ContributionBreakdown, TaxComputation, RecoveryPlan | None]:
    """Resolve all monetary amounts for the period from gross, events and YTD state.

    The annual taxable income is projected as the opening YTD taxable, plus
    this run, plus ``upcoming_gross`` for the withholding slots still to
    come (net of employee INPS at the current rate).  On the last slot
    ``upcoming_gross`` is zero, so the projection equals the final taxable
    income and the conguaglio settles on it.

    Returns:
        ``(_PeriodAmounts, ContributionBreakdown, TaxComputation, RecoveryPlan | None)``
        with all rounded monetary quantities, the per-component INPS breakdown,
        the per-rule IRPEF computation, and the updated recovery plan (if any).
        An employer that is not a withholding agent computes no tax: its
        amounts carry only contributions, TFR and taxable income.
    """
    breakdown, employee_rate = run_contributions(inp)
    tfr = tfr_accrual(inp, breakdown)
    breakdown = with_tfr_compensation(inp, breakdown, tfr)
    pension = run_pension(inp)
    assistance = run_assistance(inp.assistance, inp.contributable_hours)
    if not inp.withholding_agent:
        untaxed, no_tax = untaxed_amounts(inp, breakdown, employee_rate, tfr, pension)
        return replace(untaxed, assistance=assistance), breakdown, no_tax, None
    pdr = pdr_split(inp)
    taxable = taxable_income(inp, breakdown.employee, employee_rate, pdr, pension)
    irpef = withhold_irpef(inp, taxable)
    tax_comp = irpef.tax.computation
    surtax = run_surtax(inp, taxable.projected, irpef.tax.irpef_net)
    amounts = _PeriodAmounts(
        monthly_gross=inp.monthly_gross,
        inps_employee=breakdown.employee,
        inps_employer=breakdown.employer,
        tfr=tfr,
        period_irpef=tax_comp.ordinary_tax,
        period_tratt=tax_comp.trattamento_integrativo,
        period_surtax=surtax.due,
        period_taxable=taxable.period,
        apart_inps=taxable.apart_inps,
        period_substitute_tax=pdr.substitute_tax,
        pdr_eligible=pdr.eligible,
        projected_taxable=taxable.projected,
        surtax=surtax,
        ulteriore=irpef.tax.ulteriore,
        decisions=_decisions(inp, pdr, irpef, surtax),
        pension=pension,
        issues=_issues(inp, irpef) + tfr.issues(),
        assistance=assistance,
    )
    return amounts, breakdown, tax_comp, irpef.tax.recovery_plan
