"""PayrollEngine: unified entry point for period and year payroll computation."""

from __future__ import annotations

from decimal import (
    ROUND_HALF_EVEN,
    Context,
    DivisionByZero,
    InvalidOperation,
    Overflow,
    localcontext,
)
from typing import TYPE_CHECKING, Final, Literal

from ccnl_engine.balance.opening.services import opening_state
from ccnl_engine.catalog import services as _catalog
from ccnl_engine.period.input.services import (
    competence_plan,
    next_tax_year,
    opening_balances,
    parse_mode,
    period_request,
    tax_year_plan,
)
from ccnl_engine.period.services import (
    bundled_policies,
    bundled_repository,
)
from ccnl_engine.period.services import (
    calculate_period as _calculate_period,
)
from ccnl_engine.year.competence.services import (
    calculate_competence_year as _calculate_competence_year,
)
from ccnl_engine.year.tax_year.services import (
    calculate_tax_year as _calculate_tax_year,
)

if TYPE_CHECKING:
    from ccnl_engine.assurance.policies import EngineMode
    from ccnl_engine.balance.models import PeriodState
    from ccnl_engine.balance.opening.provider.services import OpeningBalances
    from ccnl_engine.catalog.loaders import (
        ContractSummary,
        LevelSummary,
    )
    from ccnl_engine.pay_item.policies import PolicyResolver
    from ccnl_engine.period.inputs import PeriodInput
    from ccnl_engine.period.ports import KnowledgeRepository
    from ccnl_engine.period.results import PeriodResult
    from ccnl_engine.provenance.ruleset.assurance.models import RulesetAssurance
    from ccnl_engine.year.competence.inputs import CompetenceYearPlan
    from ccnl_engine.year.results import (
        CompetenceYearResult,
        TaxYearResult,
    )
    from ccnl_engine.year.tax_year.inputs import TaxYearPlan

__all__ = ["PayrollEngine"]

#: Mode names accepted in place of an :class:`EngineMode` member.
type Mode = Literal["simulation", "operational"]

#: Decimal context of every calculation, whatever the caller's thread
#: context: the defaults of :mod:`decimal`, so a host that changes
#: ``getcontext()`` does not change a cent.
_CONTEXT: Final = Context(
    prec=28,
    rounding=ROUND_HALF_EVEN,
    traps=[InvalidOperation, DivisionByZero, Overflow],
)


class PayrollEngine:
    """Unified entry point for Italian CCNL payroll computation.

    Pass explicit ``repository`` and ``policies`` arguments to inject custom
    knowledge and policy data, useful for testing or air-gapped deployments.
    Call :meth:`bundled` to create an engine backed by the package-bundled
    data.

    The ``mode`` sets the payability policy of every result (see
    :class:`~ccnl_engine.assurance.policies.EngineMode`):
    ``"simulation"`` (the default) reports ruleset readiness, while
    ``"operational"`` also blocks payment from any ruleset that is not
    ``production``.  Both modes compute the same amounts.

    Example::

        from datetime import date
        from ccnl_engine import (
            Employment, EmployerProfile, Headcount, PayrollEngine,
            PayrollRun, PeriodInput,
        )
        from ccnl_engine.inputs import Permanent

        engine = PayrollEngine.bundled()
        result = engine.calculate_period(PeriodInput(
            run=PayrollRun.regular(2026, 1),
            payment_date=date(2026, 1, 28),
            employment=Employment(
                ccnl_id="metalmeccanico-federmeccanica",
                level_code="C3",
                contract_type=Permanent(),
            ),
            employer=EmployerProfile(headcount=Headcount(50)),
        ))
        print(result.is_payable, result.period_net)
        for ruleset in result.rulesets:
            print(ruleset.id, ruleset.readiness)
    """

    def __init__(
        self,
        *,
        repository: KnowledgeRepository | None = None,
        policies: PolicyResolver | None = None,
        mode: EngineMode | Mode = "simulation",
    ) -> None:
        """Initialise the engine with explicit or bundled knowledge sources.

        Args:
            repository: Knowledge repository to use for CCNL, tax rules, and
                surtax tables.  Defaults to the package-bundled data.
            policies: Pre-loaded policy resolver for pay-item treatment rules.
                Defaults to the bundled Italian ruleset.  Pass an instance to
                avoid repeated JSON parsing across many calculations.
            mode: ``"simulation"`` or ``"operational"``; any other value
                raises
                :class:`~ccnl_engine.errors.InvalidInputError`.
        """
        self._repo: KnowledgeRepository = (
            repository if repository is not None else bundled_repository()
        )
        self._resolver: PolicyResolver = (
            policies if policies is not None else bundled_policies()
        )
        self._mode: EngineMode = parse_mode(mode)

    @classmethod
    def bundled(cls, *, mode: EngineMode | Mode = "simulation") -> PayrollEngine:
        """Create an engine backed by the package-bundled knowledge data.

        Args:
            mode: ``"simulation"`` (the default) returns amounts with their
                assurance; ``"operational"`` also requires every ruleset
                that tracks readiness to be ``production``.

        Returns:
            A :class:`PayrollEngine` instance using the shipped CCNL and
            policy JSON files.  The resolver is loaded once and cached on
            the instance.
        """
        return cls(mode=mode)

    @property
    def mode(self) -> EngineMode:
        """Payability policy of the results of this engine."""
        return self._mode

    def list_contracts(self, family: str | None = None) -> tuple[ContractSummary, ...]:
        """Return the contracts of the repository, of ``family`` when given.

        Returns:
            One summary per CCNL, sorted by ``ccnl_id``.
        """
        return _catalog.list_contracts(self._repo, family=family)

    def list_levels(self, ccnl_id: str) -> tuple[LevelSummary, ...]:
        """Return the levels of one CCNL, each code as ``Employment`` takes it.

        Args:
            ccnl_id: Slug or CNEL code; an unknown one raises
                ``UnknownCcnlError``.

        Returns:
            One summary per level, in the order of the CCNL data.
        """
        return _catalog.list_levels(self._repo, ccnl_id)

    def inspect_ruleset(self, ccnl_id: str) -> RulesetAssurance:
        """Return the identity, hash, readiness and confidence of a CCNL.

        A run of the same CCNL reports the same assurance in
        ``result.rulesets``, so a caller can check readiness before
        calculating.

        Args:
            ccnl_id: Slug (e.g. ``"metalmeccanico-federmeccanica"``) or CNEL
                code of a CCNL of the repository.

        Returns:
            The assurance of the CCNL ruleset.

        A ``ccnl_id`` that matches no CCNL of the repository raises
        :class:`~ccnl_engine.errors.UnknownCcnlError`.
        """
        return _catalog.inspect_ruleset(self._repo, ccnl_id)

    def calculate_period(self, request: PeriodInput) -> PeriodResult:
        """Compute a single payroll run.

        Args:
            request: The run, its payment date, the employment, the employer,
                the facts of the run, the prior-year facts and the opening
                state.

        Returns:
            The :class:`~ccnl_engine.period.results.PeriodResult`:
            assurance and payability, issues, decisions, amounts, closing
            state, pay items, ledger entries and capability report.
        """
        with localcontext(_CONTEXT):
            return _calculate_period(
                period_request(request),
                repo=self._repo,
                resolver=self._resolver,
                bundle_version=self._repo.bundle_version,
                mode=self._mode,
            )

    def calculate_competence_year(
        self, plan: CompetenceYearPlan
    ) -> CompetenceYearResult:
        """Compute every run of a competence year, in payment order.

        The common case: twelve months and the extra months of the CCNL,
        each paid on the plan's payment day or date.  The runs paid in the
        year settle its conguaglio on the last of them; a run paid in the
        next tax year (December paid after 12 January) opens it.  See
        :func:`~ccnl_engine.year.competence.services.calculate_competence_year`.

        Args:
            plan: The year, the employment, the employer, the prior-year
                facts, the facts per run, an optional calendar override, the
                payment day and dates, and the opening state.

        Returns:
            One result per run and the annual totals;
            ``next_opening_state`` opens the next competence year.

        A calendar override that drops or lowers an extra month the CCNL
        grants, or does not match its reason, raises
        :class:`~ccnl_engine.errors.InvalidInputError`.
        """
        with localcontext(_CONTEXT):
            return _calculate_competence_year(
                competence_plan(plan),
                repo=self._repo,
                resolver=self._resolver,
                bundle_version=self._repo.bundle_version,
                mode=self._mode,
            )

    def calculate_tax_year(self, plan: TaxYearPlan) -> TaxYearResult:
        """Compute every payment cashed in a tax year, in payment order.

        The payments of the competence years of ``plan`` attributed to its
        tax year, late payments of an earlier competence year included; the
        conguaglio falls on the last one.  See
        :func:`~ccnl_engine.year.tax_year.services.calculate_tax_year`.

        Args:
            plan: The tax year, its competence years and its opening state.

        Returns:
            One result per payment computed, the payments of the year and
            the conguaglio; ``next_opening_state`` opens the next tax year.
        """
        with localcontext(_CONTEXT):
            return _calculate_tax_year(
                tax_year_plan(plan),
                repo=self._repo,
                resolver=self._resolver,
                bundle_version=self._repo.bundle_version,
                mode=self._mode,
            )

    @staticmethod
    def close_tax_year(closing_state: PeriodState) -> PeriodState:
        """Open the next tax year from the closing state of the last run.

        See :func:`~ccnl_engine.year.tax_year.closing.rules.close_tax_year`.

        Args:
            closing_state: ``closing_state`` of the last run of the year.

        Returns:
            The opening state of the next tax year: a fresh tax year state
            and the obligations still running.
        """
        with localcontext(_CONTEXT):
            return next_tax_year(closing_state)

    @staticmethod
    def import_opening_balances(balances: OpeningBalances) -> PeriodState:
        """Return the state that opens a run after another provider's totals.

        The one way to start from totals the engine did not compute: a
        mid-year takeover, the INPS base of the worker's other employers of
        the year, the competence runs of an earlier tax year a late
        December follows, or recoveries still running.  The totals are
        verified against the payments that produced them.

        Args:
            balances: The totals, payments and obligations to import.

        Returns:
            The opening state, bound to ``balances.tax_year``.
        """
        with localcontext(_CONTEXT):
            return opening_state(opening_balances(balances))
