"""Employment contract types and the employment relationship."""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from decimal import Decimal
from typing import Literal

from ccnl_engine.collection.validators import frozenset_of
from ccnl_engine.compensation.individual.inputs import (
    IndividualElement,
    check_individual_elements,
)
from ccnl_engine.contribution.ceiling.inputs import ContributionHistory
from ccnl_engine.employment.category.models import (
    WorkerCategory,
    parse_worker_category,
)
from ccnl_engine.employment.fact.inputs import (
    FEATURE,
    PublicEndOfService,
    WeeklyHours,
    WorkPattern,
    check_pattern_hours,
    check_within_full_time,
)
from ccnl_engine.employment.fixed_term.inputs import FixedTerm
from ccnl_engine.employment.period.inputs import EmploymentPeriod
from ccnl_engine.pension_fund.inputs import (
    PENSION_FUND_TYPES,
    NoPensionFund,
    PensionFundEnrolment,
)
from ccnl_engine.personal_withholding.inputs import (
    PersonalWithholding,
    check_personal_withholdings,
)
from ccnl_engine.regime.models import EmploymentSector
from ccnl_engine.seniority.inputs import SeniorityFact
from ccnl_engine.severance.provision.models import TfrFundBalance
from ccnl_engine.validators import (
    FieldSpec,
    parse_enum,
    reject,
    require_decimal,
    require_instances,
    require_int,
    require_str,
)

__all__ = ["Apprentice", "Contract", "Employment", "FixedTerm", "Permanent"]

_CONTRACT_FEATURE = "contract_type"
#: A CCNL file name of the bundle: no directory, no other extension.
_CCNL_ID = re.compile(r"[a-z0-9][a-z0-9-]*|[A-Z][A-Z0-9]{3}")


@dataclass(frozen=True, slots=True)
class Permanent:
    """Standard open-ended (permanent) employment contract."""

    type: Literal["permanent"] = field(default="permanent", init=False)


@dataclass(frozen=True, slots=True)
class Apprentice:
    """Apprenticeship contract; salary is derived from CCNL apprenticeship rules.

    Attributes:
        months_elapsed: Months of apprenticeship service elapsed so far,
            ``>= 0``.  Used to look up the applicable ``apprenticeship_pct``
            in the CCNL percentage track, or the under-classification level
            in under-classification tracks.
        track: Name of the CCNL apprenticeship track to apply. Required
            only when more than one track covers the destination level;
            ``None`` lets the engine select the unique applicable track.

    Raises:
        InvalidInputError: When ``months_elapsed`` is not a non-negative
            int or ``track`` is not a non-blank string.
    """

    months_elapsed: int
    track: str | None = None
    type: Literal["apprentice"] = field(default="apprentice", init=False)

    def __post_init__(self) -> None:  # noqa: D105
        require_int(
            self.months_elapsed,
            "Apprentice.months_elapsed",
            feature=_CONTRACT_FEATURE,
            minimum=0,
        )
        require_str(
            self.track,
            "Apprentice.track",
            feature=_CONTRACT_FEATURE,
            non_blank=True,
            optional=True,
        )


#: Every supported employment contract type.
type Contract = Permanent | FixedTerm | Apprentice


def _role(value: object, path: str) -> str:
    require_str(value, path, feature=FEATURE, non_blank=True)
    return str(value)


@dataclass(frozen=True)
class Employment:
    """The employment relationship: contract, level and worker facts.

    Facts are validated on construction: a value of the wrong type or an
    impossible combination raises
    :class:`~ccnl_engine.errors.InvalidInputError` instead of
    producing a payslip.

    Attributes:
        ccnl_id: The CCNL, by slug (lower-case letters, digits and
            hyphens, e.g. ``"metalmeccanico-federmeccanica"``) or by CNEL
            code (e.g. ``"E042"``).  An id the repository does not hold, or
            a CNEL code shared by several CCNLs, raises
            :class:`~ccnl_engine.errors.UnknownCcnlError` when the run loads
            it.
        level_code: Contractual level code, e.g. ``"C3"``.
        contract_type: :class:`Permanent`, :class:`FixedTerm` or :class:`Apprentice`,
            always stated: it selects the NASpI surcharge of a fixed-term contract and
            the art. 13 TUIR deduction minimum.
        category: Worker category; its string value (e.g. ``"operaio"``) is accepted and
            normalized.  ``None`` takes the category fixed by the level, if any.  The
            calculation raises when the category differs from the one the level fixes,
            or when it is ``None`` and seniority increments for the level differ by
            category.
        employment_period: Start and optional end of the employment. ``None`` when not
            tracked: a year then computes every run of the calendar with full ratei.
        weekly_hours: Contracted weekly hours.  Required for domestic CCNLs to select
            the INPS bracket; below ``full_time_weekly_hours`` it scales the pay for
            part time.
        full_time_weekly_hours: Full-time weekly hours of the contract. ``weekly_hours``
            must not exceed it.
        work_pattern: Vertical or mixed part time: the hours of each day of the week,
            whose sum must equal ``weekly_hours``, and the months of the year the worker
            works.  A month not worked pays no monthly pay and accrues no extra-month
            rateo.  ``None`` for a horizontal part time or a full time worked every
            month.
        seniority: Recognised seniority, aged by the engine to each run. ``None`` means
            not known: a run whose level pays seniority increments or service-gated
            allowances then has a ``missing_fact`` blocker, and its amounts leave them
            out.
        roles: Role codes that unlock role-specific contractual allowances, each a
            non-blank string.  A set is accepted and stored as a frozenset; an empty set
            states that the worker holds no role. ``None`` means not known: a run whose
            level has an allowance restricted to a role then has a ``missing_fact``
            blocker, and its amounts leave the allowance out.
        contribution_history: First enrolment in a mandatory pension scheme and
            contributory option, from which the engine derives whether the IVS massimale
            applies.  ``None`` means not known: a run whose INPS base crosses the
            massimale then has an undetermined contribution and a ``missing_fact``
            blocker.
        sector: Private or public sector of the employment, for the regimes restricted
            to one sector.  ``None`` means not known: those regimes are then ``unknown``
            and the result provisional.  It is not derived from the CCNL: a public
            employer may apply a private CCNL.
        pension_fund: Enrolment in a complementary pension fund of the CCNL, or
            :class:`~ccnl_engine.pension_fund.inputs.NoPensionFund` to state that the
            worker is not enrolled: no fund contribution is computed, and on a CCNL that
            has funds the ``pension_fund_contribution`` capability records the reason
            ``not_enrolled``.  ``None`` means not known: on every CCNL but domestic work
            the contributions are undetermined and the run has a ``missing_fact``
            blocker.
        tfr_fund: TFR fund at 31 December of the year before the run, the base of the
            revaluation at 31 December (art. 2120 c. 4 c.c.). ``None`` means not known:
            the December run then has a ``missing_fact`` blocker, unless the employment
            starts in the year of the run (no fund to revalue).
        tfr_treasury_fund: Whether the TFR not paid to a pension fund is paid to the
            Fondo Tesoreria INPS (L. 296/2006 art. 1 c. 756): the employer is obliged by
            its size and the worker is not excluded (DM 30 gennaio 2007 art. 1 cc. 5-8).
            ``None`` means not known: a run that accrues TFR in the company then has a
            ``missing_fact`` blocker.  Domestic work and the public administrations are
            outside the Fondo: ``True`` there raises ``InvalidInputError``, ``None`` and
            ``False`` keep the TFR in the company.
        erc_amount: Annual Elemento di Raccordo Contrattuale of the CCNL grafici
            editoriali (renewal of 19 January 2021), frozen in December 2020; zero when
            the worker has none.  It is paid with the tredicesima, by its months, and
            sets the Byblos employer rate (1.4% with one, 1.9% without).  ``None`` means
            not known, zero for an employment that started after December 2020: an
            enrolled run, or a run paying the tredicesima, on that CCNL has a
            ``missing_fact`` blocker.
        public_end_of_service: End-of-service regime of a public employee (TFS, TFR at
            INPS or TFR at the employer), which sets the contributions to INPS Gestione
            Dipendenti Pubblici and whether the run accrues the TFR.  ``None`` means not
            known: a run on a CCNL of the public administrations has a ``missing_fact``
            blocker.
        individual_elements: Pay elements agreed with the worker above the
            CCNL minimum (superminimo, assegno ad personam), each with its
            own code; a list is accepted and stored as a tuple.
        personal_withholdings: Garnishments and salary assignments notified
            to the employer, each a
            :class:`~ccnl_engine.personal_withholding.inputs.PersonalWithholding`
            with its own id; a list is accepted and stored as a tuple.

    Raises:
        InvalidInputError: When a field is not of its type, a role is not a
            non-blank string, ``weekly_hours`` exceeds ``full_time_weekly_hours``
            or differs from the weekday hours of ``work_pattern``, ``category``
            or ``sector`` names no known value, or two individual elements or
            withholdings share a code.
    """

    ccnl_id: str
    level_code: str
    contract_type: Permanent | Apprentice | FixedTerm
    category: WorkerCategory | None = None
    employment_period: EmploymentPeriod | None = None
    weekly_hours: WeeklyHours | None = None
    full_time_weekly_hours: WeeklyHours | None = None
    work_pattern: WorkPattern | None = None
    seniority: SeniorityFact | None = None
    roles: frozenset[str] | None = None
    contribution_history: ContributionHistory | None = None
    sector: EmploymentSector | None = None
    pension_fund: PensionFundEnrolment | NoPensionFund | None = None
    tfr_fund: TfrFundBalance | None = None
    tfr_treasury_fund: bool | None = None
    erc_amount: Decimal | None = None
    public_end_of_service: PublicEndOfService | None = None
    individual_elements: tuple[IndividualElement, ...] = ()
    personal_withholdings: tuple[PersonalWithholding, ...] = ()

    def __post_init__(self) -> None:  # noqa: D105
        if not isinstance(self.ccnl_id, str) or not _CCNL_ID.fullmatch(self.ccnl_id):
            reject(
                "Employment.ccnl_id",
                "a CCNL slug such as 'metalmeccanico-federmeccanica' or a "
                "CNEL code such as 'E042'",
                self.ccnl_id,
                feature=FEATURE,
            )
        require_str(
            self.level_code, "Employment.level_code", feature=FEATURE, non_blank=True
        )
        require_instances("Employment", self._typed_fields(), feature=FEATURE)
        if self.roles is not None:
            roles = frozenset_of(self.roles, "Employment.roles", _role, feature=FEATURE)
            object.__setattr__(self, "roles", roles)
        object.__setattr__(self, "category", parse_worker_category(self.category))
        if self.sector is not None:
            sector = parse_enum(
                self.sector, EmploymentSector, "Employment.sector", feature=FEATURE
            )
            object.__setattr__(self, "sector", sector)
        if self.public_end_of_service is not None:
            regime = parse_enum(
                self.public_end_of_service,
                PublicEndOfService,
                "Employment.public_end_of_service",
                feature=FEATURE,
            )
            object.__setattr__(self, "public_end_of_service", regime)
        check_within_full_time(self.weekly_hours, self.full_time_weekly_hours)
        check_pattern_hours(self.weekly_hours, self.work_pattern)
        elements = check_individual_elements(
            self.individual_elements, "Employment.individual_elements"
        )
        object.__setattr__(self, "individual_elements", elements)
        withholdings = check_personal_withholdings(
            self.personal_withholdings, "Employment.personal_withholdings"
        )
        object.__setattr__(self, "personal_withholdings", withholdings)
        require_decimal(
            self.erc_amount,
            "Employment.erc_amount",
            feature=FEATURE,
            minimum=Decimal(0),
            optional=True,
        )

    def check_seniority_in(self, year: int, month: int) -> None:
        """Reject a seniority whose recognised service starts after a month.

        The run of the month ages :attr:`seniority` to it; checking on the
        input rejects a seniority that cannot be aged to the first run
        before any calculation, with
        :class:`~ccnl_engine.errors.InvalidInputError`.

        Args:
            year: Year of the competence month of the run.
            month: Competence month of the run, 1-12.
        """
        if self.seniority is not None:
            self.seniority.months_in_month(year, month)

    def _typed_fields(self) -> tuple[FieldSpec, ...]:
        return (
            (
                "contract_type",
                self.contract_type,
                (Permanent, Apprentice, FixedTerm),
                False,
            ),
            ("employment_period", self.employment_period, EmploymentPeriod, True),
            ("weekly_hours", self.weekly_hours, WeeklyHours, True),
            ("full_time_weekly_hours", self.full_time_weekly_hours, WeeklyHours, True),
            ("work_pattern", self.work_pattern, WorkPattern, True),
            ("seniority", self.seniority, SeniorityFact, True),
            (
                "contribution_history",
                self.contribution_history,
                ContributionHistory,
                True,
            ),
            ("pension_fund", self.pension_fund, PENSION_FUND_TYPES, True),
            ("tfr_fund", self.tfr_fund, TfrFundBalance, True),
            ("tfr_treasury_fund", self.tfr_treasury_fund, bool, True),
        )
