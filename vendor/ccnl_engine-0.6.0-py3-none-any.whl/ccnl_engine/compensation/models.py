"""Compensation, allowance, and level models for CCNL contracts."""

from datetime import date
from decimal import Decimal
from enum import StrEnum
from typing import Self

from pydantic import BaseModel, ConfigDict, Field, model_validator

from ccnl_engine.agreement.validity.rules import TimeSeries
from ccnl_engine.compensation.hourly.models import HourlyPay
from ccnl_engine.compensation.renewal_minimum.models import RenewalAgreement
from ccnl_engine.compensation.una_tantum.models import UnaTantum
from ccnl_engine.employment.category.models import WorkerCategory
from ccnl_engine.fund.assistance.models import AssistanceContribution
from ccnl_engine.fund.health.models import ContractualFund
from ccnl_engine.fund.models import (
    ContractualFundContribution,
    EmployerFund,
)
from ccnl_engine.fund.solidarity.models import SolidarityFund
from ccnl_engine.provenance.source.rule.models import ProvenanceStatus, RuleProvenance
from ccnl_engine.seniority.models import SeniorityIncrements


class Allowance(BaseModel):
    """A named fixed monthly allowance attached to a CCNL level.

    ``role`` restricts the allowance to workers holding that role (``None``
    means every worker at the level). ``months_per_year`` overrides the
    contract-wide ``additional_months`` for this allowance only. The
    relevance flags exclude the allowance from the TFR base (with the
    end-of-service base of a public employee and the fund bases on it) or the
    apprenticeship-percentage base.  ``contribution_relevant`` false is
    rejected: the engine does not take an allowance out of the INPS base.
    ``apprenticeship_pct_relevant=False`` means the allowance is paid at full
    value even for percentage-based apprentices (e.g. the EDR, which Italian
    CCNL commonly leave out of the elements the apprenticeship percentage
    applies to).  The default ``True`` reduces the allowance by the
    percentage together with the base salary; a CCNL that lists the reduced
    elements exempts every allowance it does not list.

    ``individual=True`` marks an element of the worker, not of the CCNL
    (:class:`~ccnl_engine.compensation.individual.inputs.IndividualElement`):
    the hourly base counts it as the CCNL says
    (:class:`~ccnl_engine.working_time.supplement.models.IndividualElementsRule`).

    ``in_service_on`` limits the allowance to the workers in service on
    that day (Logistica Confetra art. 60 c. 8: the EDR of the workers "in
    servizio alla data del 26 gennaio 2011"): it is paid only when the
    employment started on or before it, and not when the start is unknown.
    ``service_months_threshold`` makes the allowance conditional: it is
    included only when the recognised seniority (``Employment.seniority``)
    is known and is at least this many months on the run. When the
    seniority is unknown, threshold-gated allowances are excluded and the
    run names the missing fact: the engine cannot gate on service time
    without knowing service time.  ``service_months_until`` closes the band
    of seniority: the allowance is included only below it (the RPD of the
    AFAM docenti, by band of anzianità di servizio).

    ``part_time_proportionable=False`` marks allowances that must be paid at
    their full contractual value regardless of the worker's part-time fraction
    (e.g. fixed-amount welfare contributions or presence-based indennità that
    Italian CCNL explicitly exclude from proportional reduction). Defaults to
    ``True`` so all existing allowances remain proportionable.

    ``replaced_by_provincial_element=True`` marks a national element paid
    only where no provincial element replaces it (Commercio Art. 215, terzo
    elemento): ``EmployerProfile.provincial_pay_element`` decides it.

    ``in_kind=True`` marks the conventional value of a benefit the employer
    provides in kind (the board and lodging of a live-in domestic worker,
    CCNL lavoro domestico art. 36): a regular run pays no cash for it but
    counts it in the TFR base, and an extra-month run pays it in cash.
    """

    model_config = ConfigDict(extra="forbid", frozen=True)

    code: str
    description: str
    monthly: TimeSeries
    role: str | None = None
    months_per_year: int | None = Field(default=None, ge=1)
    tfr_relevant: bool = True
    contribution_relevant: bool = True
    apprenticeship_pct_relevant: bool = True
    part_time_proportionable: bool = True
    in_kind: bool = False
    replaced_by_provincial_element: bool = False
    service_months_threshold: int | None = Field(default=None, ge=0)
    service_months_until: int | None = Field(default=None, ge=1)
    in_service_on: date | None = None
    individual: bool = False
    provenance: RuleProvenance | None = None

    @model_validator(mode="after")
    def _check_contribution_relevant(self) -> Self:
        if not self.contribution_relevant:
            msg = (
                f"allowance {self.code}: contribution_relevant false is not "
                "supported, the INPS base would keep it"
            )
            raise ValueError(msg)
        return self

    @property
    def apprenticeship_pct_declared(self) -> bool:
        """Whether the data states ``apprenticeship_pct_relevant``.

        ``False`` when the flag holds its default: whether the CCNL reduces
        the allowance for percentage apprentices was not sourced.
        """
        return "apprenticeship_pct_relevant" in self.model_fields_set


class AccrualComparison(StrEnum):
    """How the accruing days of a month are compared with the threshold.

    Attributes:
        AT_LEAST: The month counts when its days reach the threshold
            ("pari o superiore a 15 giorni").
        MORE_THAN: The month counts when its days exceed the threshold
            ("frazione superiore a 15 giorni").
        WORKING_DAYS_26: No threshold: a month not worked in full accrues
            its accruing days from Monday to Saturday as twenty-sixths of a
            rateo, at most one (CCNL Turismo 2024, art. 160 c. 2: "i giorni
            lavorati - determinati in ventiseiesimi - [...] daranno diritto
            alla maturazione di un ugual numero di ventiseiesimi di un
            rateo mensile").
        DAYS_365: A whole month accrues a twelfth, a month served in part
            a 365th of the year for each day served (CCNL Sanità 2022-2024
            art. 60 c. 4: "per le frazioni di mese, in ragione di un
            trecentosessantacinquesimo per i giorni prestati nel mese").
        DAYS_360: As ``DAYS_365`` with a 360th for each day of a month
            served in part (CCNL Area I 21 April 2006 art. 63 c. 4).
        SERVICE_DAYS_365: Every day served accrues a 365th of the year,
            whole months too (CCNL Funzioni Locali 16 November 2022 art. 75
            c. 3: "in ragione di tanti 365esimi quanti sono i giorni di
            servizio prestato").
        CUMULATED_FRACTIONS: A whole month accrues a rateo; the days of the
            months served in part are summed, and each 30 days accrue a
            rateo, a remainder of 15 days or more one more (CCNL Pubblici
            Esercizi 8 February 2018 art. 183 c. 2: "le frazioni di mese
            saranno cumulate [...] un rateo mensile per ogni trenta giorni
            di calendario, nonché per la eventuale frazione residua pari o
            superiore a quindici giorni").
    """

    AT_LEAST = "at_least"
    MORE_THAN = "more_than"
    WORKING_DAYS_26 = "working_days_26"
    DAYS_365 = "days_365"
    DAYS_360 = "days_360"
    SERVICE_DAYS_365 = "service_days_365"
    CUMULATED_FRACTIONS = "cumulated_fractions"

    @property
    def by_days(self) -> bool:
        """Whether the rule accrues days rather than comparing a threshold."""
        return self not in {AccrualComparison.AT_LEAST, AccrualComparison.MORE_THAN}


_SHORTEST_MONTH_DAYS = 28


class ExtraMonthAccrualRule(BaseModel):
    """When a month of an extra-month accrual window counts as a whole month.

    The CCNL clause on the ratei of the tredicesima and quattordicesima: a
    fraction of a month counts as a whole month when its days compare with
    ``min_days`` as ``comparison`` says, or, for the day-based comparisons,
    accrues its days.  The field is stored only
    when the signed text states it; without it the engine applies its
    default and the provenance inventory reports the rule as ``missing``.

    Attributes:
        min_days: Threshold in calendar days; ``None`` for a day-based
            comparison, which has none.
        comparison: How a month is counted (:class:`AccrualComparison`).
        working_days: The threshold counts the accruing days from Monday
            to Saturday instead of calendar days (CCNL Cooperative sociali
            art. 79: "superiore ai 15 giorni lavorativi", the week counted
            on six days by art. 60).
        provenance: Source of the clause; ``missing`` is not allowed, a
            rule without a source is left out of the data instead.
        valid_from: First day the clause applies, when a renewal changed
            it; the months starting before it follow :attr:`previous`.
        previous: The clause of the months before :attr:`valid_from`.

    Raises:
        ValueError: When a full 28-day month would not count, when the
            threshold is below one day, when a threshold is set or left out
            against the comparison, or when the provenance is ``missing``.
    """

    model_config = ConfigDict(extra="forbid", frozen=True)

    min_days: int | None = None
    comparison: AccrualComparison
    working_days: bool = False
    provenance: RuleProvenance
    valid_from: date | None = None
    previous: "ExtraMonthAccrualRule | None" = None

    @model_validator(mode="after")
    def _check_threshold(self) -> Self:
        if self.provenance.status is ProvenanceStatus.MISSING:
            msg = "a stored accrual rule needs a source; omit it when missing"
            raise ValueError(msg)
        days = self.min_days
        if self.comparison.by_days:
            if days is not None or self.working_days:
                msg = (
                    f"{self.comparison.value} has no threshold; "
                    "leave min_days and working_days out"
                )
                raise ValueError(msg)
            return self
        more_than = self.comparison is AccrualComparison.MORE_THAN
        lowest, highest = (0, 27) if more_than else (1, _SHORTEST_MONTH_DAYS)
        if days is None or not lowest <= days <= highest:
            msg = (
                f"min_days must be between {lowest} and {highest} for "
                f"{self.comparison.value!r}; got {days}"
            )
            raise ValueError(msg)
        return self


class PaymentDay(BaseModel):
    """Calendar day on which the CCNL pays an extra month.

    Attributes:
        month: Month of the payment, 1-12.
        day: Day of the month, 1-28 so that every month has it.
        provenance: Source of the clause; ``missing`` is not allowed, a
            day without a source is left out of the data instead.

    Raises:
        ValueError: When the provenance is ``missing``.
    """

    model_config = ConfigDict(extra="forbid", frozen=True)

    month: int = Field(ge=1, le=12)
    day: int = Field(ge=1, le=28)
    provenance: RuleProvenance

    @model_validator(mode="after")
    def _check_source(self) -> Self:
        if self.provenance.status is ProvenanceStatus.MISSING:
            msg = "a stored payment day needs a source; omit it when missing"
            raise ValueError(msg)
        return self


class RaccordoElement(BaseModel):
    """Frozen annual amount the CCNL pays with the tredicesima.

    The Elemento di Raccordo Contrattuale of the CCNL grafici editoriali
    (renewal of 19 January 2021): an amount per worker, stated by
    ``Employment.erc_amount``, that accrues by month as the tredicesima
    and has "alcuna incidenza su alcun istituto contrattuale o di legge".
    """

    model_config = ConfigDict(extra="forbid", frozen=True)

    provenance: RuleProvenance


class CCNLParameters(BaseModel):
    """Contract-wide parameters.

    ``accrual_rule`` is the CCNL threshold for counting a month of an
    extra-month window, ``None`` when the bundle has no sourced clause.
    ``thirteenth_payment_day``, ``fourteenth_payment_day``: the days the CCNL
    pays the extra months, ``None`` without a sourced clause.
    ``assistance_contribution``, ``contractual_fund_contribution``: charged
    per paid hour and per month to a fund, ``None`` when it charges none.
    ``flat_pay_max_weekly_hours``: hours paid at the full minimum (domestic: 30).
    ``raccordo_element``: the ERC the CCNL pays with the tredicesima.
    ``enam_levels``: the levels whose permanent workers owe the contribution
    of the Gestione Assistenza Magistrale (ex ENAM, L. 93/1957 art. 3).
    ``solidarity_fund``: its fund of D.Lgs. 148/2015 art. 26, if modelled.
    ``renewals``: the renewals that raised the minimo, each with its signing
    date and the first day of its first tranche, read by the renewal regime
    of L. 199/2025 to measure the increment on the table before it.
    ``health_funds``: the health and bilateral funds owed for every worker,
    each with the elemento distinto owed instead when the employer does not
    pay it (``EmployerProfile.contractual_funds``).
    ``hourly_pay``: the worker categories paid by the hour worked and the
    percentages on those hours (the operai of the CCNL edilizia).
    ``una_tantum``: the one-off amounts of its renewals for their vacancy.
    """

    model_config = ConfigDict(extra="forbid", frozen=True)

    hourly_divisor: TimeSeries
    additional_months: TimeSeries
    seniority_increments: SeniorityIncrements
    employer_funds: tuple[EmployerFund, ...] = Field(default=())
    accrual_rule: ExtraMonthAccrualRule | None = None
    thirteenth_payment_day: PaymentDay | None = None
    fourteenth_payment_day: PaymentDay | None = None
    assistance_contribution: AssistanceContribution | None = None
    flat_pay_max_weekly_hours: int | None = Field(default=None, ge=1)
    contractual_fund_contribution: ContractualFundContribution | None = None
    raccordo_element: RaccordoElement | None = None
    enam_levels: tuple[str, ...] = ()
    solidarity_fund: SolidarityFund | None = None
    hourly_pay: HourlyPay | None = None
    renewals: tuple[RenewalAgreement, ...] = ()
    health_funds: tuple[ContractualFund, ...] = ()
    una_tantum: tuple[UnaTantum, ...] = ()

    @model_validator(mode="after")
    def _check_positive_params(self) -> Self:
        """Reject non-positive hourly_divisor or additional_months values.

        Both divide the pay: a zero or negative value is a data-entry error.

        Returns:
            The validated instance (required by Pydantic model_validator).

        Raises:
            ValueError: If any non-gap period in either series has value <= 0.
        """
        for field_name, series in (
            ("hourly_divisor", self.hourly_divisor),
            ("additional_months", self.additional_months),
        ):
            for p in series.periods:
                if p.value is not None and p.value <= 0:
                    msg = (
                        f"{field_name} values must be > 0; "
                        f"period starting {p.valid_from} has value {p.value}"
                    )
                    raise ValueError(msg)
        return self


class Level(BaseModel):
    """A single classification level (*livello di inquadramento*).

    Attributes:
        code: Short alphanumeric code identifying the level within the CCNL
            (e.g. ``"D3"``, ``"A1"``). Used in ``Scenario.level_code``.
        order: Numeric ranking from lowest to highest seniority/pay (1 = lowest).
            Used by ``CCNL.level_by_order``.
        description: Human-readable name of the classification level.
        base_salary: Time-series of monthly base salaries for this level.
        fixed_allowances: List of fixed monthly allowances attached to the
            level (e.g. EDR, contingenza). May be empty.
        category: Worker category fixed by this level. ``None`` when the
            level hosts more than one category; the category then comes from
            the employment facts (``Employment.category``).
    """

    model_config = ConfigDict(extra="forbid", frozen=True)

    code: str
    order: int
    description: str
    base_salary: TimeSeries
    fixed_allowances: tuple[Allowance, ...] = Field(default=())
    category: WorkerCategory | None = None
    provenance: RuleProvenance | None = None

    @model_validator(mode="after")
    def _check_salary_non_decreasing(self) -> Self:
        # Compare only adjacent non-gap periods; gap periods carry no value.
        values: list[Decimal] = [
            p.value for p in self.base_salary.periods if p.value is not None
        ]
        for i in range(len(values) - 1):
            if values[i + 1] < values[i]:
                msg = (
                    f"base_salary must be non-decreasing over time: "
                    f"period {i} value {values[i]} > "
                    f"period {i + 1} value {values[i + 1]}"
                )
                raise ValueError(msg)
        return self
