"""Totals of the events of a run: bases, decisions, issues and features."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING

from ccnl_engine.balance.cash.account.models import RegimeCapAccount
from ccnl_engine.event.facade import (
    AbsenceEvent,
    ArrearsEvent,
    BilateralFundEvent,
    BoardLodgingEvent,
    DisabilityPermitEvent,
    ExtraordinaryLeaveEvent,
    FringeEvent,
    HolidayWorkEvent,
    HourlyParentalLeaveEvent,
    LeaveTakenEvent,
    MaternityLeaveEvent,
    NightShiftEvent,
    NoticeIndemnityEvent,
    NursingRestEvent,
    OvertimeEvent,
    ParentalLeaveEvent,
    PaternityLeaveEvent,
    ShiftWorkEvent,
    SickLeaveEvent,
    SicknessEpisode,
    StandbyEvent,
    TerminationTFREvent,
    TravelAllowanceEvent,
    WelfareEvent,
    WorkInjuryEvent,
)
from ccnl_engine.pay_item.services import _ZERO
from ccnl_engine.sickness.models import SicknessHistory

if TYPE_CHECKING:
    from datetime import date
    from decimal import Decimal

    from ccnl_engine.decision.models import (
        CalculationDecision,
        CalculationIssue,
    )
    from ccnl_engine.event.facade import WorkEvent
    from ccnl_engine.event.handlers import EventEffect
    from ccnl_engine.leave.balance.models import LeaveAccount
    from ccnl_engine.ledger.models import PostingIntent
    from ccnl_engine.pay_item.facade import PayItem
    from ccnl_engine.sickness.models import SicknessEpisode

#: Catalog feature each event type executes.  A bonus has none of its own:
#: its PdR substitute tax is the ``bonus_pdr`` decision of the run.
EVENT_FEATURES: dict[type, str] = {
    OvertimeEvent: "overtime",
    NightShiftEvent: "night_work",
    HolidayWorkEvent: "holiday_work",
    ShiftWorkEvent: "shift_work",
    StandbyEvent: "standby",
    AbsenceEvent: "absence",
    SickLeaveEvent: "sickness",
    SicknessEpisode: "sickness",
    MaternityLeaveEvent: "maternity_leave",
    PaternityLeaveEvent: "paternity_leave",
    ParentalLeaveEvent: "parental_leave",
    DisabilityPermitEvent: "disability_permits",
    NursingRestEvent: "nursing_rests",
    HourlyParentalLeaveEvent: "parental_leave",
    NoticeIndemnityEvent: "termination_notice",
    ExtraordinaryLeaveEvent: "extraordinary_leave",
    WorkInjuryEvent: "workplace_injury",
    FringeEvent: "fringe_benefit",
    TravelAllowanceEvent: "travel_allowance",
    WelfareEvent: "welfare",
    ArrearsEvent: "contract_renewal_arrears",
    BilateralFundEvent: "bilateral_funds",
    TerminationTFREvent: "termination_tfr",
    LeaveTakenEvent: "leave",
    BoardLodgingEvent: "board_lodging",
}


def _has_effect(effect: EventEffect) -> bool:
    """Return whether a handler posted a non-zero amount or took a decision.

    Returns:
        ``True`` when ``effect`` changes the payslip or records a decision.
    """
    return bool(effect.decisions) or any(i.amount for i in effect.intents)


@dataclass(frozen=True)
class _EventTotals:
    """Aggregated INPS/TFR/IRPEF bases, decisions and issues of the events.

    ``executed_features`` are the catalog features of the events whose
    handler had an effect (see :func:`_has_effect`).  ``separate_irpef_base``
    is the part of ``irpef_base`` withheld apart from the pay of the period
    (art. 23 c. 2 lett. b) DPR 600/1973); ``apart_inps_base`` the part of
    ``inps_base`` taxed apart (art. 17 TUIR).  ``leave`` is the leave account
    after the run, set by :func:`~ccnl_engine.leave.services.run_leave`;
    ``None`` leaves the account of the opening state unchanged.
    """

    inps_base: Decimal
    tfr_base: Decimal
    irpef_base: Decimal
    fringe_value: Decimal
    fringe_inps: Decimal
    fringe_irpef: Decimal
    substitute_base: Decimal
    work_time_cap_used: Decimal = _ZERO
    separate_irpef_base: Decimal = _ZERO
    apart_inps_base: Decimal = _ZERO
    decisions: tuple[CalculationDecision, ...] = ()
    issues: tuple[CalculationIssue, ...] = ()
    executed_features: frozenset[str] = frozenset()
    sickness_episodes: tuple[SicknessEpisode, ...] | None = None
    limitations: frozenset[str] = frozenset()
    leave: LeaveAccount | None = None


@dataclass
class _EventAccumulator:
    """Running totals of the events of a run, updated after each handler.

    The fringe accumulators and the work-time regime cap feed the context of
    the next event, and so do the sickness episodes recorded so far; the
    rest is summed into :class:`_EventTotals`.
    """

    cumulative_fringe: Decimal
    cumulative_taxed: Decimal
    opening_cap: RegimeCapAccount
    work_time_cap: RegimeCapAccount
    inps: Decimal = _ZERO
    tfr: Decimal = _ZERO
    irpef: Decimal = _ZERO
    separate_irpef: Decimal = _ZERO
    apart_inps: Decimal = _ZERO
    substitute: Decimal = _ZERO
    fringe_value: Decimal = _ZERO
    fringe_inps: Decimal = _ZERO
    fringe_irpef: Decimal = _ZERO
    items: list[PayItem] = field(default_factory=list)
    intents: list[PostingIntent] = field(default_factory=list)
    decisions: list[CalculationDecision] = field(default_factory=list)
    issues: list[CalculationIssue] = field(default_factory=list)
    executed: set[str] = field(default_factory=set)
    sickness: SicknessHistory = field(default_factory=SicknessHistory)
    sickness_changed: bool = False
    sick_units: Decimal = _ZERO
    sick_days: set[date] = field(default_factory=set)
    limitations: set[str] = field(default_factory=set)

    def add(self, event: WorkEvent, result: EventEffect) -> None:
        """Add the effect of one event handler to the running totals."""
        self.items.extend(result.items)
        self.intents.extend(result.intents)
        self.decisions.extend(result.decisions)
        self.issues.extend(result.issues)
        feature = EVENT_FEATURES.get(type(event))
        if feature is not None and _has_effect(result):
            self.executed.add(feature)
        self.inps += result.inps_delta
        self.tfr += result.tfr_delta
        self.irpef += result.irpef_delta
        self.separate_irpef += result.separate_irpef_delta
        self.apart_inps += result.apart_inps_delta
        self.substitute += result.substitute_delta
        self.fringe_value += result.fringe_value
        self.fringe_inps += result.fringe_inps
        self.fringe_irpef += result.fringe_irpef
        self.work_time_cap = RegimeCapAccount(
            self.work_time_cap.used + result.regime_cap_used
        )
        if result.new_cumulative_fringe is not None:
            self.cumulative_fringe = result.new_cumulative_fringe
        if result.new_cumulative_taxed is not None:
            self.cumulative_taxed = result.new_cumulative_taxed
        self.limitations.update(result.limitations)
        if result.sickness_episode is not None:
            self.sickness = SicknessHistory(
                self.sickness.with_episode(result.sickness_episode)
            )
            self.sickness_changed = True
        self.sick_units += result.sick_units
        self.sick_days.update(result.sick_days)

    def totals(self) -> _EventTotals:
        """Return the aggregated bases, decisions and issues of the events.

        Returns:
            The :class:`_EventTotals` of every event added so far.
        """
        return _EventTotals(
            inps_base=self.inps,
            tfr_base=self.tfr,
            irpef_base=self.irpef,
            fringe_value=self.fringe_value,
            fringe_inps=self.fringe_inps,
            fringe_irpef=self.fringe_irpef,
            substitute_base=self.substitute,
            work_time_cap_used=self.work_time_cap.used - self.opening_cap.used,
            separate_irpef_base=self.separate_irpef,
            apart_inps_base=self.apart_inps,
            decisions=tuple(self.decisions),
            issues=tuple(self.issues),
            executed_features=frozenset(self.executed),
            sickness_episodes=(
                self.sickness.episodes if self.sickness_changed else None
            ),
            limitations=frozenset(self.limitations),
        )
