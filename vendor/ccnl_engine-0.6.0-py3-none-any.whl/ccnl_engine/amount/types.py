"""Inputs and outputs of the amounts of one run."""

from __future__ import annotations

from dataclasses import dataclass, field
from decimal import Decimal
from typing import TYPE_CHECKING

from ccnl_engine.contribution.additional_ivs.rules import AdditionalIvsPosition
from ccnl_engine.fund.contractual.rules import ContractualRun
from ccnl_engine.irpef.rules import DAYS_IN_YEAR
from ccnl_engine.run.models import RunKind
from ccnl_engine.surtax.rules import RunSurtax
from ccnl_engine.tax_credit.recovery.models import InstallmentRun

if TYPE_CHECKING:
    from ccnl_engine.balance.cash.models import TaxCashState
    from ccnl_engine.contribution.services import TfrAccrual
    from ccnl_engine.decision.models import (
        CalculationDecision,
        CalculationIssue,
    )
    from ccnl_engine.employment.category.models import WorkerCategory
    from ccnl_engine.employment.fact.inputs import PublicEndOfService
    from ccnl_engine.employment.inputs import Apprentice, FixedTerm, Permanent
    from ccnl_engine.family.inputs import FamilyComposition
    from ccnl_engine.family.models import FamilyDeductionRules
    from ccnl_engine.fund.assistance.rules import (
        AssistanceContribution,
        AssistanceTerms,
    )
    from ccnl_engine.fund.solidarity.models import SolidarityFund
    from ccnl_engine.irpef.other_income.inputs import CurrentYearTaxFacts
    from ccnl_engine.pension_fund.rules import (
        PensionContribution,
        PensionFundTerms,
    )
    from ccnl_engine.sector.models import YearRules
    from ccnl_engine.surtax.models import SurtaxRules
    from ccnl_engine.surtax.obligation.models import SurtaxObligation
    from ccnl_engine.tax_credit.foreign.inputs import ForeignTaxPaid
    from ccnl_engine.tax_credit.recovery.models import RecoveryPlan
    from ccnl_engine.tax_credit.ulteriore_detrazione.rules import (
        UlterioreSettlement,
    )
    from ccnl_engine.variable_pay.models import PdRRules
    from ccnl_engine.withholding.schedule.models import WithholdingPosition


@dataclass(frozen=True)
class PublicTerms:
    """What the contributions of a public employee to INPS depend on.

    Attributes:
        end_of_service: End-of-service regime (TFS, TFR at INPS or at the
            employer), ``None`` when not stated.
        life_insurance: Whether the Assicurazione Sociale Vita is owed,
            ``None`` when neither the employer nor the CCNL states it.
        enam_stipendio: Stipendio of a teacher who owes the ENAM, ``None``
            when none is owed.
    """

    end_of_service: PublicEndOfService | None = None
    life_insurance: bool | None = None
    enam_stipendio: Decimal | None = None


@dataclass(frozen=True)
class _AmountsInput:
    """Everything the amounts of one run are computed from.

    ``upcoming_gross`` is the recurring gross of the withholding slots still
    to come, zero on the last slot.  ``eligible_work_days`` are the days of
    employment in the tax year the deductions are proportioned to: the union
    of the employments the tax cash state paid in it, the run's included.
    ``fixed_term_in_year`` tells whether one of them is fixed-term, which
    sets the art. 13 c. 1 lett. a) TUIR minimum at 1,380 EUR.
    ``period_days`` are the days of the pay period of a regular run, zero
    for any other run.  ``event_separate_base`` is the part of
    ``event_irpef_base`` withheld apart from the pay of the period (art. 23
    c. 2 lett. b) DPR 600/1973), and so is the whole of an
    :attr:`additional_month` run.  ``event_apart_inps_base`` is the part
    of ``event_inps_base`` taxed apart (art. 17 TUIR): its employee
    contributions are no deduction of the ordinary taxable.
    ``recovery_plan`` is the installment recovery opened in this tax year,
    if one is running, ``ulteriore_plan`` the ulteriore detrazione plan
    opened by a conguaglio of this tax year.  ``installment_run`` tells
    whether the run is the last of the employment, which defers nothing and
    settles every running plan, or an adjustment run.
    ``withholding_agent`` is false for an employer that withholds no tax
    (see :mod:`~ccnl_engine.withholding.agent.rules`).
    ``pension`` holds the rates of the pension fund the worker is enrolled
    in, ``None`` when not enrolled; ``contractual_fund`` the contribution
    the CCNL owes a fund for every worker.  ``conguaglio`` is true on the run that
    settles the tax year: its last withholding slot, or the last run of the
    employment.  ``surtax_obligations`` is the surtax determined by an
    earlier conguaglio still to withhold; ``run_month`` and ``run_kind``
    place the run in the installment windows.
    ``foreign_taxes`` are credited on the conguaglio only.
    ``deferred_irpef`` is the IRPEF a conguaglio of this tax year deferred
    on written request: it counts as withheld when the balance is settled
    again.  ``additional_ivs`` is the position of the run toward the
    additional 1% IVS of its competence year.  ``tfr_treasury_fund`` says
    whether the TFR not paid to a pension fund goes to the Fondo Tesoreria,
    ``None`` when not known.  ``assistance`` holds the rates of the
    contractual assistance contribution, ``None`` when the CCNL charges
    none.  ``in_kind`` is the value of the benefits the
    pay chain provides in kind, which enters the TFR base only.
    ``inps_minimum`` is the minimum INPS base of
    the run (:mod:`~ccnl_engine.contribution.minimum_base.rules`), ``None``
    when none is determined.
    """

    monthly_gross: Decimal
    in_kind: Decimal
    event_inps_base: Decimal
    event_tfr_base: Decimal
    event_irpef_base: Decimal
    event_substitute_base: Decimal
    opening: TaxCashState
    ytd_inps_base: Decimal
    withholding: WithholdingPosition
    upcoming_gross: Decimal
    rules: YearRules
    contract_type: Permanent | FixedTerm | Apprentice
    category: WorkerCategory | None
    pdr_rules: PdRRules
    ivs_ceiling_applies: bool
    inps_minimum: Decimal | None = None
    surtax_rules: SurtaxRules | None = None
    regione: str | None = None
    comune_belfiore: str | None = None
    family_composition: FamilyComposition | None = None
    family_deduction_rules: FamilyDeductionRules | None = None
    current_year: CurrentYearTaxFacts | None = None
    weekly_hours: Decimal | None = None
    contributable_hours: Decimal | None = None
    domestic_hourly_rate: Decimal | None = None
    eligible_work_days: int = DAYS_IN_YEAR
    fixed_term_in_year: bool = False
    period_days: int = 0
    event_separate_base: Decimal = Decimal(0)
    event_apart_inps_base: Decimal = Decimal(0)
    recovery_plan: RecoveryPlan | None = None
    ulteriore_plan: RecoveryPlan | None = None
    installment_run: InstallmentRun = field(default_factory=InstallmentRun)
    withholding_agent: bool = True
    pension: PensionFundTerms | None = None
    contractual_fund: ContractualRun = field(default_factory=ContractualRun)
    conguaglio: bool = False
    surtax_obligations: tuple[SurtaxObligation, ...] = ()
    run_month: int = 1
    run_kind: RunKind = RunKind.REGULAR
    foreign_taxes: tuple[ForeignTaxPaid, ...] = ()
    deferred_irpef: Decimal = Decimal(0)
    additional_ivs: AdditionalIvsPosition = field(default_factory=AdditionalIvsPosition)
    tfr_treasury_fund: bool | None = None
    assistance: AssistanceTerms | None = None
    tfr_excluded: Decimal = Decimal(0)
    public: PublicTerms = field(default_factory=PublicTerms)
    solidarity_fund: SolidarityFund | None = None
    sick_pay_regime: str | None = None

    @property
    def tfr_pay(self) -> Decimal:
        """TFR base of the run, the excluded allowances left out.

        The gross, the benefits in kind and the events entering the TFR,
        less the allowances the CCNL leaves out of it.
        """
        return (
            self.monthly_gross + self.in_kind + self.event_tfr_base - self.tfr_excluded
        )

    @property
    def regular_run(self) -> bool:
        """Whether the run pays a regular month."""
        return self.run_kind is RunKind.REGULAR

    @property
    def additional_month(self) -> bool:
        """Whether the run pays a tredicesima or a quattordicesima."""
        return self.run_kind in {RunKind.THIRTEENTH, RunKind.FOURTEENTH}


@dataclass(frozen=True)
class _PeriodAmounts:
    """Computed monetary amounts passed to pay-item and ledger builders.

    Does not include period_gross, period_net or period_employer_cost: those
    are derived from the ledger after all entries are posted.  ``surtax``
    carries what the run withholds and determines of the surtax, whose
    total before the pay cap is ``surtax.due`` and after it
    ``period_surtax``;
    ``decisions`` holds every tax decision of the run, the surtax ones last.
    ``projected_taxable`` is the annual taxable income the IRPEF of the run
    was computed on; ``None`` when not recorded.  ``ulteriore`` is what
    the run recognized or recovered of the ulteriore detrazione.
    ``pension`` holds the pension fund contributions of the run, ``None``
    when the worker is not enrolled.  ``issues`` are those of the
    capabilities computed here: the family deductions and the TFR.
    ``tfr`` holds the art. 2120 c.c. quota and the additional IVS
    deducted from it.  ``assistance`` is the contractual assistance
    contribution of the run, ``None`` when the CCNL charges none.
    """

    monthly_gross: Decimal
    inps_employee: Decimal
    inps_employer: Decimal
    tfr: TfrAccrual
    period_irpef: Decimal
    period_tratt: Decimal
    period_surtax: Decimal
    period_taxable: Decimal
    period_substitute_tax: Decimal
    pdr_eligible: Decimal
    surtax: RunSurtax = field(default_factory=RunSurtax)
    decisions: tuple[CalculationDecision, ...] = ()
    projected_taxable: Decimal | None = None
    ulteriore: UlterioreSettlement | None = None
    pension: PensionContribution | None = None
    issues: tuple[CalculationIssue, ...] = ()
    assistance: AssistanceContribution | None = None
    apart_inps: Decimal = Decimal(0)
