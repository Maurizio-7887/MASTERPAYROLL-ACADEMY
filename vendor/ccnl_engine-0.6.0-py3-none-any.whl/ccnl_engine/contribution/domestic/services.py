"""Flat per-hour INPS contributions of domestic CCNLs (colf and badanti)."""

from __future__ import annotations

from decimal import Decimal
from typing import TYPE_CHECKING

from ccnl_engine.agreement.validity.rules import rule_scope
from ccnl_engine.contribution.naspi.rules import (
    SurchargeReason,
    naspi_surcharge,
)
from ccnl_engine.contribution.results import (
    ContributionBreakdown,
    ContributionComponent,
)
from ccnl_engine.errors import (
    DataIntegrityError,
    MissingRequiredFactError,
)
from ccnl_engine.pay_item.rounding.policies import money
from ccnl_engine.pay_item.services import _ZERO

_WEEKS = 52

if TYPE_CHECKING:
    from datetime import date

    from ccnl_engine.agreement.facade import CCNL
    from ccnl_engine.contribution.domestic.models import DomesticInpsRates
    from ccnl_engine.employment.inputs import Contract
    from ccnl_engine.sector.models import YearRules


def _pick_domestic_per_hour(
    dc: DomesticInpsRates,
    weekly_hours: Decimal,
    domestic_hourly_rate: Decimal,
    *,
    surcharged: bool,
) -> tuple[Decimal, Decimal]:
    """Return (employee_per_hour, employer_per_hour) for a domestic CCNL bracket.

    The fixed-term employer rates of the INPS table include the NASpI
    surcharge; they apply when the run is charged it.

    Returns:
        ``(emp_ph, empr_ph)`` flat rates to multiply by contributable hours.
    """
    if weekly_hours > dc.weekly_hours_threshold:
        emp_ph = dc.hours_bracket.employee_per_hour
        empr_ph = (
            dc.hours_bracket.employer_per_hour_fixed_term
            if surcharged
            else dc.hours_bracket.employer_per_hour
        )
    else:
        emp_ph = _ZERO
        empr_ph = _ZERO
        for wb in dc.wage_brackets:  # pragma: no branch
            if (  # pragma: no branch
                wb.hourly_rate_up_to is None
                or domestic_hourly_rate <= wb.hourly_rate_up_to
            ):
                emp_ph = wb.employee_per_hour
                empr_ph = (
                    wb.employer_per_hour_fixed_term
                    if surcharged
                    else wb.employer_per_hour
                )
                break
    return emp_ph, empr_ph


def compute_domestic_breakdown(
    rules: YearRules,
    weekly_hours: Decimal | None,
    contributable_hours: Decimal | None,
    domestic_hourly_rate: Decimal | None,
    contract_type: Contract,
) -> ContributionBreakdown:
    """Compute domestic flat-rate INPS contributions.

    Returns:
        :class:`~ccnl_engine.contribution.results.ContributionBreakdown`
        with employee and employer flat-rate contributions and per-component audit.

    Raises:
        MissingRequiredFactError: When ``weekly_hours`` or ``contributable_hours``
            is ``None``.
        DataIntegrityError: When ``domestic_contributions`` is unexpectedly absent.
    """
    dc = rules.domestic_contributions
    if dc is None:  # pragma: no cover
        msg = "YearRules has no domestic_contributions despite inps=None"
        raise DataIntegrityError(msg)
    if weekly_hours is None:
        msg = (
            "domestic CCNL requires Employment.weekly_hours "
            "to select the INPS contribution bracket"
        )
        raise MissingRequiredFactError(msg, feature="domestic_contributions")
    if contributable_hours is None:
        msg = (
            "domestic CCNL requires PeriodFacts.contributable_hours "
            "to compute INPS contributions"
        )
        raise MissingRequiredFactError(msg, feature="domestic_contributions")
    surcharge = naspi_surcharge(rules, contract_type, None, domestic=True)
    emp_ph, empr_ph = _pick_domestic_per_hour(
        dc,
        weekly_hours,
        domestic_hourly_rate or _ZERO,
        surcharged=surcharge.reason is SurchargeReason.CHARGED,
    )
    employee_contribution = money(emp_ph * contributable_hours)
    employer_contribution = money(empr_ph * contributable_hours)
    return ContributionBreakdown(
        employee=employee_contribution,
        employer=employer_contribution,
        components=(
            ContributionComponent(
                name="domestic_employee_per_hour",
                base=contributable_hours,
                rate=emp_ph,
                amount=employee_contribution,
            ),
            ContributionComponent(
                name="domestic_employer_per_hour",
                base=contributable_hours,
                rate=empr_ph,
                amount=employer_contribution,
            ),
        ),
    )


def _domestic_hourly_rate(
    ccnl: CCNL,
    year_rules: YearRules,
    monthly_pay: Decimal,
    weekly_hours: Decimal | None,
    as_of: date,
) -> Decimal | None:
    """Return the effective hourly pay that bands domestic contributions.

    The INPS bands are of the paga oraria effettiva: the agreed hourly pay,
    the board and lodging and the tredicesima spread over the hours (INPS,
    Contributi e agevolazioni fiscali per chi assume un lavoratore
    domestico).  ``monthly_pay`` is the pay of a regular month, benefits in
    kind included; it is spread over the hours of the month, ``weekly_hours``
    x 52 / 12, and raised by the additional months over the twelve.

    Returns:
        Hourly rate in EUR for domestic CCNLs, zero without pay or weekly
        hours, or ``None`` when the CCNL uses standard INPS rates.
    """
    if year_rules.domestic_contributions is None:
        return None
    if monthly_pay <= _ZERO or not weekly_hours:
        return _ZERO
    with rule_scope(ruleset=ccnl.meta.ccnl_id, feature="inps_employee"):
        months = ccnl.parameters.additional_months.value_at(as_of)
    return money(monthly_pay * months / (weekly_hours * _WEEKS))
