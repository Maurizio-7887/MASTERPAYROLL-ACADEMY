"""What a :class:`~ccnl_engine.PeriodResult` reports beyond its amounts.

Assurance and blockers, decisions and issues, model limitations, capability
gaps, unresolved requirements, runs a year left out and the remittance lines;
:func:`result_to_json` writes a whole result as JSON, and
:func:`compare_totals` compares the totals of a run with another payroll.
:data:`PUBLIC_FACTS` maps the detail of a ``missing_fact`` blocker to the
public field that supplies it.
"""

from __future__ import annotations

from ccnl_engine.assurance.models import (
    BlockerCode,
    CoverageStatus,
    EvidenceStatus,
    Payability,
    ResultAssurance,
    ResultBlocker,
)
from ccnl_engine.capability.requirement.rules import UnresolvedRequirement
from ccnl_engine.capability.results import CapabilityGap, CapabilityScope
from ccnl_engine.comparison.totals.models import (
    TOTALS,
    TotalDifference,
    TotalsComparison,
)
from ccnl_engine.comparison.totals.services import compare_totals
from ccnl_engine.decision.models import (
    PUBLIC_FACTS,
    CalculationDecision,
    CalculationIssue,
    CalculationStatus,
    DecisionOrigin,
    IssueCause,
)
from ccnl_engine.extra_month.progress.models import ExtraMonthProgress
from ccnl_engine.interchange.result.serializers import result_to_json
from ccnl_engine.ledger.models import AccountKind
from ccnl_engine.ledger.remittance.models import (
    RemittanceColumn,
    RemittanceLine,
)
from ccnl_engine.limitation.models import (
    LimitationStatus,
    ModelLimitation,
    MonetaryImpact,
)
from ccnl_engine.limitation.types import ResultTotal
from ccnl_engine.pay_item.voce.rules import VoceSide, VoceUnit
from ccnl_engine.period.payslip.line.models import PayslipLine, Progressives
from ccnl_engine.year.coverage.models import UncoveredRun

__all__ = [
    "PUBLIC_FACTS",
    "TOTALS",
    "AccountKind",
    "BlockerCode",
    "CalculationDecision",
    "CalculationIssue",
    "CalculationStatus",
    "CapabilityGap",
    "CapabilityScope",
    "CoverageStatus",
    "DecisionOrigin",
    "EvidenceStatus",
    "ExtraMonthProgress",
    "IssueCause",
    "LimitationStatus",
    "ModelLimitation",
    "MonetaryImpact",
    "Payability",
    "PayslipLine",
    "Progressives",
    "RemittanceColumn",
    "RemittanceLine",
    "ResultAssurance",
    "ResultBlocker",
    "ResultTotal",
    "TotalDifference",
    "TotalsComparison",
    "UncoveredRun",
    "UnresolvedRequirement",
    "VoceSide",
    "VoceUnit",
    "compare_totals",
    "result_to_json",
]
