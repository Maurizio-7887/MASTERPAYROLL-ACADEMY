"""Arithmetic shared by the deductions of art. 12 TUIR.

Every ratio of the formulas is taken to the decimals of the rules, the rest
discarded (art. 12 c. 4), before it multiplies an amount.  A deduction is
due for the months of the year its conditions hold (c. 3) and rounded to the
cent once, after the months and the allocation are applied.
"""

from __future__ import annotations

from dataclasses import dataclass
from decimal import ROUND_DOWN, Decimal
from typing import TYPE_CHECKING

from ccnl_engine.pay_item.rounding.policies import money

if TYPE_CHECKING:
    from ccnl_engine.family.inputs import Dependent

__all__ = [
    "MONTHS_IN_YEAR",
    "DependentDeduction",
    "phase_out",
    "prorate",
    "truncated",
]

MONTHS_IN_YEAR = 12
_ZERO = Decimal(0)
_ONE = Decimal(1)
_HUNDRED = Decimal(100)


@dataclass(frozen=True)
class DependentDeduction:
    """Deduction of one dependent for the tax year.

    Attributes:
        dependent: The dependent.
        due_months: Months of the year (1-12) the deduction is due.
        annual: Deduction for a full year at the reddito complessivo, before
            the months and the allocation; not rounded.
        amount: ``annual * months / 12 * allocation_pct / 100``, rounded to
            the cent; zero while :attr:`missing_facts` is not empty.
        missing_facts: Conditions the dependant leaves unknown while it may
            give right to the deduction in some month: until they are
            stated, the deduction is not determined and none is granted.
    """

    dependent: Dependent
    due_months: frozenset[int]
    annual: Decimal
    amount: Decimal
    missing_facts: tuple[str, ...] = ()

    @property
    def months(self) -> int:
        """Number of months of the year the deduction is due."""
        return len(self.due_months)

    def of_month(self, month: int) -> Decimal:
        """Return the deduction of one month of the year.

        Art. 12 c. 3 TUIR: the deductions "sono rapportate a mese e competono
        dal mese in cui si sono verificate a quello in cui sono cessate le
        condizioni richieste".

        Returns:
            A twelfth of :attr:`annual` times the share, rounded to the cent,
            in a month the deduction is due and determined; zero otherwise.
        """
        if self.missing_facts or month not in self.due_months:
            return _ZERO
        return money(
            self.annual / Decimal(MONTHS_IN_YEAR) * self.dependent.share / _HUNDRED
        )


def truncated(ratio: Decimal, decimals: int) -> Decimal:
    """Return ``ratio`` taken to ``decimals`` decimals, the rest discarded.

    Returns:
        The ratio rounded towards zero.
    """
    return ratio.quantize(_ONE.scaleb(-decimals), rounding=ROUND_DOWN)


def phase_out(
    amount: Decimal,
    limit: Decimal,
    span: Decimal,
    income: Decimal,
    decimals: int,
) -> Decimal:
    """Return the part of ``amount`` of the ratio ``(limit - income) / span``.

    The deduction is not due when the ratio is zero or less, or one or more
    (art. 12 c. 4); otherwise the ratio is truncated to ``decimals``.

    Returns:
        ``amount`` times the truncated ratio, not rounded.
    """
    ratio = (limit - income) / span
    if ratio <= _ZERO or ratio >= _ONE:
        return _ZERO
    return amount * truncated(ratio, decimals)


def prorate(
    dependent: Dependent, due_months: frozenset[int], annual: Decimal
) -> DependentDeduction:
    """Return the deduction of ``dependent`` for ``due_months`` of the year.

    ``due_months`` are those in which no stated condition excludes the
    deduction; a dependant that may qualify in some month with a condition
    left unknown gets no deduction and names the missing facts.

    Returns:
        The deduction, rounded to the cent after the months and allocation.
    """
    missing = dependent.missing_facts if due_months else ()
    if missing:
        return DependentDeduction(dependent, due_months, annual, _ZERO, missing)
    months = Decimal(len(due_months))
    amount = money(
        annual * months / Decimal(MONTHS_IN_YEAR) * dependent.share / _HUNDRED
    )
    return DependentDeduction(dependent, due_months, annual, amount)
