"""Payable rules of a run's capabilities, ids ``<ruleset id>:<location>``."""

from __future__ import annotations

from functools import partial
from typing import TYPE_CHECKING

from ccnl_engine.capability.rule.leave.services import (
    _leave_rules,
    _termination_leave_rules,
)
from ccnl_engine.capability.rule.time.services import (
    _absence_rules,
    _overtime_rules,
    _supplement_rules,
)
from ccnl_engine.compensation.hourly.services import percentage_rules
from ccnl_engine.contribution.additional_ivs.services import additional_ivs_rules
from ccnl_engine.employment.inputs import Apprentice, FixedTerm
from ccnl_engine.event.facade import (
    HolidayWorkEvent,
    NightShiftEvent,
    ShiftWorkEvent,
)
from ccnl_engine.extra_month.decision.services import accrual_rules
from ccnl_engine.fund.assistance.policies import assistance_rules
from ccnl_engine.fund.contractual.rules import contractual_rules
from ccnl_engine.pension_fund.inputs import PensionFundEnrolment
from ccnl_engine.severance.services import (
    revaluation_rules,
    settlement_rules,
    tfr_rules,
)
from ccnl_engine.sickness.services import sickness_rules
from ccnl_engine.surtax.jurisdiction.types import region_table_name
from ccnl_engine.termination.naspi.services import naspi_rules

if TYPE_CHECKING:
    from collections.abc import Callable

    from ccnl_engine.agreement.validity.rules import ValidityPeriod
    from ccnl_engine.period.context.services import RunContext
    from ccnl_engine.provenance.ruleset.models import RulesetIdentity
    from ccnl_engine.provenance.source.rule import models as models_chain

#: A rule the run read: its identifier and its provenance, if recorded.
type Rule = tuple[
    str, models_chain.RuleProvenance | models_chain.ProvenanceStatus | None
]


def _name(ruleset: RulesetIdentity | None, fallback: str) -> str:
    return fallback if ruleset is None else ruleset.id


def _salary_rules(ctx: RunContext) -> tuple[Rule, ...]:
    """Return the salary, allowance and extra-month rules of the run.

    Returns:
        The base salary period, the allowances of the pay chain, the extra
        months in force, the accrual rule that decided a rateo, the
        partial-month or hourly rules and the percentages on the hours.
    """
    ccnl, level = ctx.contract.ccnl, ctx.contract.level
    day = ctx.contract.tctx.competence
    name = _name(ccnl.ruleset, f"ccnl/{ccnl.meta.ccnl_id}")
    prefix = f"{name}:levels[{level.code}]"
    rules: list[Rule] = [
        (
            f"{prefix}.base_salary[{period.valid_from}]",
            period.provenance or level.provenance,
        )
        for period in _in_force(level.base_salary.period_at(day))
    ]
    rules.extend(
        (f"{prefix}.fixed_allowances[{a.code}]", a.provenance or level.provenance)
        for a, _amount in ctx.chain.allowances
    )
    rules.extend(
        (f"{name}:additional_months[{period.valid_from}]", period.provenance)
        for period in _in_force(ccnl.parameters.additional_months.period_at(day))
    )
    rules.extend(accrual_rules(ctx))
    rules.extend(ctx.proration.rules)
    rules.extend(percentage_rules(ctx))
    return tuple(rules)


def _in_force(period: ValidityPeriod | None) -> tuple[ValidityPeriod, ...]:
    return () if period is None else (period,)


def _sick_pay_supplement(ctx: RunContext, inps_name: str) -> tuple[Rule, ...]:
    """Return the additional sickness contribution of the regime of the CCNL.

    Returns:
        ``<inps>:inps.sick_pay_supplements[<regime>]`` with its record; empty
        when the CCNL names no regime or the year has no ordinary rates.
    """
    work = ctx.contract.ccnl.work_rules
    sickness = None if work is None else work.sickness_rules
    regime = None if sickness is None else sickness.inps_regime
    inps = ctx.contract.year_rules.inps
    named = next(
        (r for r in ctx.repo.load_sick_pay_rates().regimes if r.id == regime), None
    )
    if (
        regime is None
        or inps is None
        or not (named is None or named.additional_contribution)
    ):
        return ()
    supplement = inps.sick_pay_supplements.get(regime)
    record = None if supplement is None else supplement.provenance
    return ((f"{inps_name}:inps.sick_pay_supplements[{regime}]", record),)


def contract_rules(ctx: RunContext) -> dict[str, tuple[Rule, ...]]:
    """Return the CCNL and INPS rules of the run by capability.

    Returns:
        Rules of ``base_salary``, ``seniority``, ``inps_employee``,
        ``inps_employer``, ``ivs_ceiling_eligibility`` (the massimale) and
        ``assistance_contribution``.
    """
    ccnl = ctx.contract.ccnl
    name = _name(ccnl.ruleset, f"ccnl/{ccnl.meta.ccnl_id}")
    rules = ctx.contract.year_rules
    inps_name = _name(rules.inps_ruleset, f"inps/{rules.year}")
    contract = ctx.request.contract_type
    rates = (
        ("apprentice", _provenance(rules.apprentice))
        if isinstance(contract, Apprentice)
        else ("inps", _provenance(rules.inps))
    )
    minimum = None if rules.inps is None else rules.inps.minimum_base
    inps: tuple[Rule, ...] = (
        (f"{inps_name}:{rates[0]}", rates[1]),
        (
            f"{inps_name}:domestic_contributions",
            _provenance(rules.domestic_contributions),
        ),
        (f"{inps_name}:inps.minimum_base", _provenance(minimum)),
    )
    tax_name = _name(rules.ruleset, f"tax/{rules.year}")
    fixed_term: tuple[Rule, ...] = (
        (
            (
                f"{tax_name}:fixed_term_additional_rate",
                rules.fixed_term_additional_rate_provenance,
            ),
        )
        if isinstance(contract, FixedTerm)
        else ()
    )
    return {
        "base_salary": _salary_rules(ctx),
        "seniority": (
            (
                f"{name}:seniority_increments",
                ccnl.parameters.seniority_increments.provenance,
            ),
        ),
        "inps_employee": inps + additional_ivs_rules(inps_name, rules.inps),
        "inps_employer": inps + fixed_term + _sick_pay_supplement(ctx, inps_name),
        "ivs_ceiling_eligibility": (
            (
                f"{inps_name}:inps.ceiling",
                None if rules.inps is None else rules.inps.ceiling_record,
            ),
        ),
        "assistance_contribution": assistance_rules(
            ccnl, ctx.contract.tctx.competence.year
        ),
        "contractual_funds": tuple(
            (f"{name}:health_funds[{fund.code}]", fund.provenance)
            for fund in ccnl.parameters.health_funds
        ),
    }


def tax_rules(ctx: RunContext) -> dict[str, tuple[Rule, ...]]:
    """Return the tax-file and variable-pay rules of the run by capability.

    Returns:
        Rules of the IRPEF, TFR, TFR revaluation, credit and variable-pay
        capabilities.
    """
    rules, var = ctx.contract.year_rules, ctx.var_pay_rules
    name = _name(rules.ruleset, f"tax/{rules.year}")
    var_name = _name(var.ruleset, f"tax/variable-pay-rules/{var.year}")
    somma = rules.somma_esente
    somma_name = _name(somma.ruleset if somma else None, f"tax/{rules.year}/somma")
    return {
        "irpef": (
            (f"{name}:irpef_brackets", rules.irpef_brackets_provenance),
            (f"{name}:work_deduction", rules.work_deduction.provenance),
            (
                f"{name}:work_deduction.minimum",
                rules.work_deduction.minimum.provenance,
            ),
        ),
        "tfr": tfr_rules(name, rules.tfr),
        "tfr_revaluation": revaluation_rules(
            rules.tfr_revaluation, ctx.contract.tctx.competence.year
        ),
        "termination_tfr": (
            *tfr_rules(name, rules.tfr),
            *settlement_rules(rules.tfr_settlement),
            (f"{name}:irpef_brackets", rules.irpef_brackets_provenance),
        ),
        "trattamento_integrativo": (
            (
                f"{name}:trattamento_integrativo",
                _provenance(rules.trattamento_integrativo),
            ),
        ),
        "ulteriore_detrazione_lavoro": (
            (f"{name}:ulteriore_detrazione", _provenance(rules.ulteriore_detrazione)),
        ),
        "somma_esente": ((f"{somma_name}:somma_esente", _provenance(somma)),),
        "fringe_benefit": (
            (f"{var_name}:fringe_benefit", var.fringe_benefit.provenance),
        ),
        "bonus_pdr": ((f"{var_name}:pdr", var.pdr.provenance),),
        "travel_allowance": (
            (f"{var_name}:travel_allowance", var.travel_allowance.provenance),
        ),
        "rinnovo_substitute_tax": ((f"{var_name}:rinnovo", var.rinnovo.source_status),),
        "notte_festivi_turni_substitute_tax": (
            (
                f"{var_name}:notte_festivi_turni",
                var.notte_festivi_turni.source_status,
            ),
        ),
    }


def _provenance(block: object) -> models_chain.RuleProvenance | None:
    provenance: models_chain.RuleProvenance | None = getattr(block, "provenance", None)
    return provenance


def _surtax_rules(ctx: RunContext, *, regional: bool) -> tuple[Rule, ...]:
    """Return the surtax table rule of the run for one jurisdiction.

    An entry of the table may carry its own record; otherwise the record of
    the table applies.

    Returns:
        The rule of the jurisdiction, empty when no table was loaded.
    """
    surtax = ctx.repo.load_surtax_rules(ctx.fiscal_year)
    if surtax is None:
        return ()
    request = ctx.request
    if regional:
        key = region_table_name(request.regione or "") or ""
        entry: object = surtax.regionale.get(key)
        table, ruleset = surtax.regional_provenance, surtax.regional_ruleset
        fallback = f"surtax/{surtax.year}/regionale"
    else:
        key = request.comune_belfiore or ""
        entry = surtax.comunale.get(key)
        table, ruleset = surtax.municipal_provenance, surtax.municipal_ruleset
        fallback = f"surtax/{surtax.year}/comunale"
    return ((f"{_name(ruleset, fallback)}:rates[{key}]", _provenance(entry) or table),)


def _family_rules(ctx: RunContext) -> tuple[Rule, ...]:
    """Return the Art. 12 TUIR family deduction rules of the run.

    Returns:
        The spouse, spouse increase, children and other-dependent rules.
    """
    rules = ctx.repo.load_family_deduction_rules(ctx.fiscal_year)
    name = _name(rules.ruleset, f"tax/{rules.year}/family-deductions")
    return (
        (f"{name}:spouse", rules.spouse.provenance),
        (f"{name}:spouse_increases", rules.spouse_increases.provenance),
        (f"{name}:children", rules.children.provenance),
        (f"{name}:other_dependents", rules.other_dependents.provenance),
    )


def _pension_rules(ctx: RunContext) -> tuple[Rule, ...]:
    """Return the fund rates and the statutory pension rules of the run.

    Returns:
        The fund rates, the contractual amount, the cap and solidarity rate.
    """
    ccnl = ctx.contract.ccnl
    enrolment = ctx.request.pension_fund
    code = enrolment.fund_code if isinstance(enrolment, PensionFundEnrolment) else ""
    funds = [f for f in ccnl.parameters.employer_funds if f.code == code]
    day = ctx.contract.tctx.competence
    ccnl_name = _name(ccnl.ruleset, f"ccnl/{ccnl.meta.ccnl_id}")
    rules: list[Rule] = [
        (
            f"{ccnl_name}:employer_funds[{code}].{key}[{period.valid_from}]",
            period.provenance or fund.provenance,
        )
        for fund in funds
        for key, series in (
            *fund.rate_series(),
            *((f"tier[{t.employee_from}]", t.rate) for t in fund.employer_rate_tiers),
        )
        if series is not None
        for period in _in_force(series.period_at(day))
    ]
    rules.extend(contractual_rules(ctx, ccnl_name))
    year_rules = ctx.contract.year_rules
    tax_name = _name(year_rules.ruleset, f"tax/{year_rules.year}")
    rules.append((
        f"{tax_name}:complementary_pension",
        _provenance(year_rules.complementary_pension),
    ))
    return tuple(rules)


def _standby_rules(ctx: RunContext) -> tuple[Rule, ...]:
    """Return the CCNL standby rules the standby of the run was paid with.

    Returns:
        ``<ccnl>:work_rules.standby_rules`` with its record, ``None`` as
        the record when the CCNL has none (a standby event then fails, so
        a run never reports it).
    """
    ccnl = ctx.contract.ccnl
    work = ccnl.work_rules
    standby = None if work is None else work.standby_rules
    name = _name(ccnl.ruleset, f"ccnl/{ccnl.meta.ccnl_id}")
    record = None if standby is None else standby.provenance
    return ((f"{name}:work_rules.standby_rules", record),)


#: Capabilities whose rules need a load, done only when the capability ran.
LOADED: dict[str, Callable[[RunContext], tuple[Rule, ...]]] = {
    "overtime": _overtime_rules,
    "night_work": partial(_supplement_rules, event_type=NightShiftEvent),
    "holiday_work": partial(_supplement_rules, event_type=HolidayWorkEvent),
    "shift_work": partial(_supplement_rules, event_type=ShiftWorkEvent),
    "absence": _absence_rules,
    "standby": _standby_rules,
    "addizionale_regionale": partial(_surtax_rules, regional=True),
    "addizionale_comunale": partial(_surtax_rules, regional=False),
    "family_deductions": _family_rules,
    "pension_fund_contribution": _pension_rules,
    "sickness": sickness_rules,
    "leave": _leave_rules,
    "termination_residual_leave": _termination_leave_rules,
    "naspi_dismissal": naspi_rules,
}
