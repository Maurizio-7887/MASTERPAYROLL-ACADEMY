"""Contributions to the end-of-service fund and the credit of a public employee.

INPS Gestione Dipendenti Pubblici finances the TFS and the TFR of the
public employees with a contribution on 80% of the pay: ENPAS for the
State, INADEL for the enti locali and the health service
(:class:`~ccnl_engine.contribution.rate.models.EndOfServiceRates`).
Under the TFS the worker pays 2.50% of the base and the administration the
rest.  Under the TFR at INPS the administration pays the whole contribution
and "la retribuzione lorda viene ridotta in misura pari al contributo
previdenziale obbligatorio soppresso" (DPCM 20 dicembre 1999 art. 1 c. 3):
the run posts that reduction as a negative earning of the gross
(:mod:`~ccnl_engine.severance.public.services`), so
the net, the IRPEF taxable and the cost of the administration equal those
of the TFS ("La soppressione del contributo non determina effetti sulla
retribuzione imponibile ai fini fiscali", c. 2), while the INPS and the
end-of-service bases keep the unreduced pay (the recupero of c. 3).  An
employer that keeps the TFR itself (c. 6 and 8) pays the Gestione nothing.
"""

from __future__ import annotations

from dataclasses import replace
from decimal import Decimal
from typing import TYPE_CHECKING

from ccnl_engine.contribution.results import ContributionComponent
from ccnl_engine.decision.models import (
    CalculationIssue,
    CalculationStatus,
)
from ccnl_engine.employment.fact.inputs import PublicEndOfService
from ccnl_engine.pay_item.rounding.policies import money

if TYPE_CHECKING:
    from ccnl_engine.amount.types import _AmountsInput
    from ccnl_engine.contribution.rate.models import EndOfServiceRates
    from ccnl_engine.contribution.results import ContributionBreakdown

__all__ = [
    "END_OF_SERVICE_UNKNOWN",
    "LIFE_INSURANCE_UNKNOWN",
    "end_of_service_base",
    "end_of_service_employee_rate",
    "end_of_service_issue",
    "life_insurance_issue",
    "with_enam",
    "with_end_of_service",
    "with_life_insurance",
    "with_public_credit",
]

_ZERO = Decimal(0)
#: A public employer needs to state whether it owes the ASV.
LIFE_INSURANCE_UNKNOWN = CalculationIssue(
    code="public_life_insurance_unknown",
    capability="inps_employee",
    message=(
        "the employers of the CCNL differ on the Assicurazione Sociale Vita "
        "(ex ENPDEP): every ente di diritto pubblico owes it but the State, the "
        "Province and the Comuni (INPS circ. 104/2014); the amounts shown leave "
        "it out; state EmployerProfile.public_life_insurance"
    ),
    status=CalculationStatus.INCOMPLETE,
    fact="public_life_insurance",
)
#: A public employee needs the end-of-service regime to be stated.
END_OF_SERVICE_UNKNOWN = CalculationIssue(
    code="public_end_of_service_unknown",
    capability="inps_employee",
    message=(
        "the contributions of a public employee to INPS Gestione Dipendenti "
        "Pubblici and the accrual of the TFR depend on the end-of-service "
        "regime (TFS, TFR at INPS or TFR at the employer), which the "
        "employment does not state: the amounts shown leave the "
        "contributions out; state Employment.public_end_of_service"
    ),
    status=CalculationStatus.INCOMPLETE,
    fact="public_end_of_service",
)


def end_of_service_issue(inp: _AmountsInput) -> CalculationIssue | None:
    """Return the missing-fact issue of a public employee without a regime.

    Returns:
        :data:`END_OF_SERVICE_UNKNOWN` when the year has end-of-service
        rates for the CCNL and the regime is not stated, else ``None``.
    """
    rates = None if inp.rules.inps is None else inp.rules.inps.end_of_service
    if rates is None or inp.public.end_of_service is not None:
        return None
    return END_OF_SERVICE_UNKNOWN


def _component(name: str, base: Decimal, rate: Decimal) -> ContributionComponent:
    return ContributionComponent(name, base, rate, money(base * rate))


def _components(
    inp: _AmountsInput,
) -> tuple[tuple[ContributionComponent, ...], tuple[ContributionComponent, ...]]:
    """Return the employee and employer components of the run.

    Returns:
        Nothing without rates or a regime with contributions to the
        Gestione, or on a tredicesima the fund leaves out of the base.
    """
    rates = None if inp.rules.inps is None else inp.rules.inps.end_of_service
    regime = inp.public.end_of_service
    pay = inp.tfr_pay
    base = end_of_service_base(rates, regime, pay, extra=inp.additional_month)
    if rates is None or base is None:
        return (), ()
    if regime is PublicEndOfService.TFS:
        return (
            (_component("tfs_employee", base, rates.tfs_employee_rate),),
            (_component("tfs_employer", base, rates.tfs_employer_rate),),
        )
    return (), (_component("tfr_employer", base, rates.tfr_employer_rate),)


def end_of_service_base(
    rates: EndOfServiceRates | None,
    regime: PublicEndOfService | None,
    pay: Decimal,
    *,
    extra: bool,
) -> Decimal | None:
    """Return the end-of-service base of a run, ``None`` when it has none.

    Args:
        rates: End-of-service rates of the CCNL's fund, ``None`` outside the
            public administrations.
        regime: End-of-service regime of the worker.
        pay: TFR base of the run, the unreduced pay (DPCM art. 1 c. 3).
        extra: Whether the run pays a tredicesima or a quattordicesima.

    Returns:
        80% of ``pay`` under the TFS or the TFR at INPS, unless the fund
        leaves the extra month out of its base.
    """
    at_inps = regime in {PublicEndOfService.TFS, PublicEndOfService.TFR_INPS}
    if rates is None or not at_inps or (extra and not rates.thirteenth):
        return None
    return money(pay * rates.base_share)


def with_end_of_service(
    inp: _AmountsInput, breakdown: ContributionBreakdown
) -> ContributionBreakdown:
    """Return ``breakdown`` with the end-of-service contributions of the run.

    Returns:
        The breakdown with the employee and employer components added to
        its totals, employee components before the employer ones.
    """
    employee, employer = _components(inp)
    return _added(breakdown, employee, employer)


def _added(
    breakdown: ContributionBreakdown,
    employee: tuple[ContributionComponent, ...],
    employer: tuple[ContributionComponent, ...] = (),
) -> ContributionBreakdown:
    """Return ``breakdown`` with components added, employee ones first.

    Returns:
        The breakdown with the amounts added to its totals.
    """
    if not employee and not employer:
        return breakdown
    components = breakdown.components
    split = next(
        (i for i, c in enumerate(components) if c.name.endswith("_employer")),
        len(components),
    )
    return replace(
        breakdown,
        employee=breakdown.employee + sum((c.amount for c in employee), _ZERO),
        employer=breakdown.employer + sum((c.amount for c in employer), _ZERO),
        components=(*components[:split], *employee, *components[split:], *employer),
    )


def end_of_service_employee_rate(inp: _AmountsInput) -> Decimal:
    """Return the share of the gross the worker gives up for the fund.

    Returns:
        The 2.50% of the worker times the share of the base, under the TFS
        (a contribution) or the TFR at INPS (a reduction of the gross); zero
        otherwise.  It projects the taxable of the slots still to come.
    """
    rates = None if inp.rules.inps is None else inp.rules.inps.end_of_service
    pay = inp.tfr_pay
    base = end_of_service_base(rates, inp.public.end_of_service, pay, extra=False)
    if rates is None or base is None:
        return _ZERO
    return rates.tfs_employee_rate * rates.base_share


def with_public_credit(
    inp: _AmountsInput, breakdown: ContributionBreakdown, pension_base: Decimal
) -> tuple[ContributionBreakdown, Decimal]:
    """Return ``breakdown`` with the credit contribution of a public employee.

    L. 662/1996 art. 1 c. 242: 0.35% of the "retribuzione contributiva e
    pensionabile", the pension base of the run, whatever the regime, and
    within the IVS massimale of the worker when it applies (INPS, "I
    contributi dei dipendenti pubblici": "nei limiti del massimale
    contributivo eventualmente applicabile al lavoratore").

    Returns:
        The breakdown with the ``credit_employee`` component, and its rate;
        ``breakdown`` and zero outside the public administrations.
    """
    credit = None if inp.rules.inps is None else inp.rules.inps.public_credit
    if credit is None:
        return breakdown, _ZERO
    component = _component("credit_employee", pension_base, credit.employee_rate)
    return _added(breakdown, (component,)), credit.employee_rate


def life_insurance_issue(inp: _AmountsInput) -> CalculationIssue | None:
    """Return the missing-fact issue of an ASV the employer does not state.

    Returns:
        :data:`LIFE_INSURANCE_UNKNOWN` when the year has ASV rates for the
        CCNL and neither the employer nor the CCNL decides it.
    """
    rates = None if inp.rules.inps is None else inp.rules.inps.public_life_insurance
    if rates is None or inp.public.life_insurance is not None:
        return None
    return LIFE_INSURANCE_UNKNOWN


def with_life_insurance(
    inp: _AmountsInput, breakdown: ContributionBreakdown, pension_base: Decimal
) -> tuple[ContributionBreakdown, Decimal]:
    """Return ``breakdown`` with the ASV contributions of a public employee.

    INPS circ. 104/2014 par. 3.1: 0.027% of the worker and 0.093% of the
    employer on the pension base, "coincidente con quella assoggettata alla
    contribuzione ai fini pensionistici": within the IVS massimale.

    Returns:
        The breakdown with the ``life_insurance_*`` components and the
        employee rate; ``breakdown`` and zero when no ASV is owed.
    """
    rates = None if inp.rules.inps is None else inp.rules.inps.public_life_insurance
    if rates is None or not inp.public.life_insurance:
        return breakdown, _ZERO
    employee = _component("life_insurance_employee", pension_base, rates.employee_rate)
    employer = _component("life_insurance_employer", pension_base, rates.employer_rate)
    return _added(breakdown, (employee,), (employer,)), rates.employee_rate


def with_enam(
    inp: _AmountsInput, breakdown: ContributionBreakdown
) -> tuple[ContributionBreakdown, Decimal]:
    """Return ``breakdown`` with the ENAM of a permanent teacher.

    L. 93/1957 art. 3 c. 1 lett. a: 1% of 80% of the stipendio.

    Returns:
        The breakdown with the ``enam_employee`` component and its rate on
        the gross; ``breakdown`` and zero when no ENAM is owed.
    """
    rates = None if inp.rules.inps is None else inp.rules.inps.public_enam
    if rates is None or inp.public.enam_stipendio is None:
        return breakdown, _ZERO
    base = money(inp.public.enam_stipendio * rates.base_share)
    component = _component("enam_employee", base, rates.employee_rate)
    return _added(breakdown, (component,)), rates.employee_rate * rates.base_share
