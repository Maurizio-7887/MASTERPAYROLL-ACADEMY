"""ccnl_engine.knowledge — versioned dataset bundle (data only).

Passive JSON resources consumed by the capability loaders (contract, tax,
payroll), ordered as ``domain/dataset/year/scope.json`` and indexed by
``manifest.json``: every resource is listed there once, with its identity,
model, validity, ruleset and wheel name.  The JSON carries no Python logic,
so it can be upgraded or redistributed independently of the engine.  The
only code is :mod:`ccnl_engine.bundle.loaders`, which reads the resources
through the manifest.

Datasets:
- ``agreement/<slug>.json`` — one file per CCNL.
- ``sector/<year>/<sector>.json`` and ``taxation/<dataset>/<year>.json``
  — IRPEF, deductions, TFR, somma esente, variable pay, TFR revaluation.
- ``contribution/<year>/<sector>.json`` and
  ``sickness/indemnity/rates.json`` — INPS rates and sick pay.
- ``surtax/regional|municipal/<year>.json`` — addizionali.
- ``capability/registry/<year>.json``, ``limitation/engine.json``,
  ``pay_item/italy.json``.

The version of the bundled data is :data:`SERIES` followed by a digest of
the manifest (:func:`ccnl_engine.bundle.loaders.bundle_version`): two
bundles that differ in any resource never share a version.
"""

#: Release series of the knowledge base, bumped by hand for a new tax year or
#: a schema change; the digest of the manifest tells the bundles of a series
#: apart.
SERIES = "2026.3"
