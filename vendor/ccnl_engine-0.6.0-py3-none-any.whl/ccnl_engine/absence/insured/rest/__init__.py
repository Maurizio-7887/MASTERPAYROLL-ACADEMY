"""The ``rest`` domain of an insured absence (package marker, no code)."""
