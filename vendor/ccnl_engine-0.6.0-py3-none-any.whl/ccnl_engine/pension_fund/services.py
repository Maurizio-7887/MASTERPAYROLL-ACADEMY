"""Pension fund contributions of one run and their effect on the taxable."""

from __future__ import annotations

from decimal import Decimal
from typing import TYPE_CHECKING

from ccnl_engine.decision.models import (
    CalculationIssue,
    CalculationStatus,
)
from ccnl_engine.fund.models import FundContributionBase
from ccnl_engine.pension_fund.rules import (
    contractual_only,
    contribute,
    upcoming_adjustment,
)

if TYPE_CHECKING:
    from ccnl_engine.amount.types import _AmountsInput
    from ccnl_engine.pension_fund.rules import (
        PensionContribution,
        PensionFundTerms,
    )

_ZERO = Decimal(0)
#: A fund with a young member rate needs the enrolment to state it.
YOUNG_MEMBER_UNKNOWN = CalculationIssue(
    code="pension_fund_young_member_unknown",
    capability="pension_fund_contribution",
    message=(
        "the fund has a higher employer rate for members enrolled young "
        "(Cometa: after 5 February 2021, before turning 35) and the enrolment "
        "does not state it: the amounts shown use the base rate; state "
        "PensionFundEnrolment.young_member"
    ),
    status=CalculationStatus.INCOMPLETE,
    fact="young_member",
)
#: A fund with an ERC holder rate needs the employment to state the ERC.
ERC_UNKNOWN = CalculationIssue(
    code="pension_fund_erc_unknown",
    capability="pension_fund_contribution",
    message=(
        "Byblos has a lower employer rate (1.4%) for the holders of the "
        "Elemento di Raccordo Contrattuale of the CCNL grafici editoriali and "
        "the employment does not state it: the amounts shown use the base "
        "rate; state Employment.erc_amount"
    ),
    status=CalculationStatus.INCOMPLETE,
    fact="erc_amount",
)
#: A fund on a conventional base needs the enrolment to state it.
CONVENTIONAL_BASE_UNKNOWN = CalculationIssue(
    code="pension_fund_conventional_base_unknown",
    capability="pension_fund_contribution",
    message=(
        "the fund computes its rates on a conventional base of the worker "
        "(Previambiente: the 1997 base pay, contingenza and one scatto of the "
        "level) and the enrolment does not state it: the amounts shown leave "
        "the rates out; state PensionFundEnrolment.conventional_base"
    ),
    status=CalculationStatus.INCOMPLETE,
    fact="conventional_base",
)


def conventional_base_unknown(terms: PensionFundTerms | None) -> bool:
    """Return whether the fund is on a conventional base the enrolment omits.

    Returns:
        True when the worker is enrolled in a fund on a conventional base
        and the enrolment does not state it.
    """
    conventional = FundContributionBase.CONVENTIONAL
    return (
        terms is not None
        and terms.fund.contribution_base is conventional
        and terms.conventional_base is None
        and terms.employee_rate > 0
    )


def run_pension(inp: _AmountsInput) -> PensionContribution | None:
    """Return the fund contributions of the run, on the base of the fund.

    The base is the one the fund names: the INPS base of the run, the TFR
    base (the recurring gross, the benefits in kind and the events entering
    the TFR, e.g. Fon.Te.) or the contractual minimum (Cometa).  An employee
    rate above the minimum is computed on the base the fund sets for it,
    when it sets one (Cometa: the TFR base).  A fund due on the twelve
    monthly payments alone has a zero base on an extra-month run, and a
    fund due on the pay of the month (``paid_month_only``) on a run without
    pay; neither owes its fixed amount of an enrolled worker there.

    The contractual contribution of the CCNL is added to the employer part,
    and is the whole contribution of a worker not enrolled voluntarily.

    Returns:
        ``None`` when the worker is not enrolled and owes no contractual
        contribution.
    """
    deducted = inp.opening.earnings.pension_deducted
    if inp.pension is None:
        if inp.contractual_fund.amount == _ZERO:
            return None
        rules = inp.rules.complementary_pension
        return contractual_only(inp.contractual_fund.amount, rules, deducted)
    terms = inp.pension
    bases = {
        FundContributionBase.INPS_BASE: inp.monthly_gross + inp.event_inps_base,
        FundContributionBase.TFR_BASE: inp.tfr_pay,
        FundContributionBase.CONTRACTUAL_MINIMUM: terms.minimum_base,
        FundContributionBase.CONVENTIONAL: terms.conventional_base or _ZERO,
    }
    fund = terms.fund
    fixed = terms.enrolled_monthly
    unpaid = fund.paid_month_only and bases[FundContributionBase.INPS_BASE] <= 0
    if (inp.additional_month and not fund.extra_months) or unpaid:
        bases, fixed = dict.fromkeys(bases, _ZERO), _ZERO
    base = bases[fund.contribution_base]
    above = fund.employee_base_above_minimum
    minimum = terms.employee_min_rate
    chosen_more = minimum is not None and terms.employee_rate > minimum
    employee_base = bases[above] if above is not None and chosen_more else None
    contractual = inp.contractual_fund.amount + fixed
    return contribute(terms, base, deducted, contractual, employee_base)


def projected_adjustment(
    inp: _AmountsInput, pension: PensionContribution | None
) -> Decimal:
    """Return the taxable change of the fund on the slots still to come.

    The recurring gross still to come is taken as their INPS base, as the
    projection of the employee INPS does.  A contractual contribution alone
    stays within the cap: the projection leaves it out.

    Returns:
        Zero when the worker is not enrolled.
    """
    if pension is None or pension.terms is None:
        return _ZERO
    deducted = inp.opening.earnings.pension_deducted + pension.deductible
    return upcoming_adjustment(pension.terms, inp.upcoming_gross, deducted)
