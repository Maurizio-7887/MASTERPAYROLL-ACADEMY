"""Deductions from gross IRPEF of employment income.

Implements the Art. 13 co. 1 TUIR work-income deduction (piecewise-linear
schedule of D.Lgs. 216/2023 and L. 207/2024), its proportion to the days of
work and the minimum of lett. a) for a fixed-term or open-ended employment,
proportioned to the days as the withholding agent applies it.

The detrazioni per carichi di famiglia (Art. 12 TUIR) are in
:mod:`~ccnl_engine.family.services`.  The art. 16-ter
c. 5-bis TUIR reduction does not apply to either: see
:mod:`~ccnl_engine.irpef.net.rules`.
"""

from __future__ import annotations

from decimal import ROUND_FLOOR, Decimal

from ccnl_engine.irpef.models import WorkDeductionRules
from ccnl_engine.irpef.rules import DAYS_IN_YEAR
from ccnl_engine.pay_item.rounding.policies import money

_ZERO = Decimal(0)
_TEN_THOUSAND = Decimal(10000)


def _trunc4(ratio: Decimal) -> Decimal:
    """Truncate an income ratio of art. 13 TUIR to four decimal places.

    Art. 13 c. 6 TUIR: "Se il risultato dei rapporti indicati nei commi 1,
    3, 4 e 5 è maggiore di zero, lo stesso si assume nelle prime quattro
    cifre decimali".  It covers the income ratios of those commi only, not
    the proportion to the days of work (see :func:`for_days`).

    Returns:
        The ratio truncated toward zero to four decimal places.
    """
    return (ratio * _TEN_THOUSAND).to_integral_value(
        rounding=ROUND_FLOOR
    ) / _TEN_THOUSAND


def for_days(full_year: Decimal, eligible_work_days: int) -> Decimal:
    """Proportion a full-year credit to the days of work in the year.

    Art. 13 c. 1 TUIR, L. 207/2024 art. 1 c. 6 and D.L. 3/2020 art. 1 give
    the amount "rapportata al periodo di lavoro nell'anno"; the 730/2026
    istruzioni count the days of work with "365 per l'intero anno" (quadro
    C, periodo di lavoro), so the amount is ``amount * days / 365``.  The
    four-decimal truncation of art. 13 c. 6 TUIR is not applied: the days
    are not one of the ratios it lists.  The full-year amount is rounded to
    cents first, as the tables state it in euro.

    Returns:
        ``money(money(full_year) * eligible_work_days / 365)``.
    """
    return money(money(full_year) * eligible_work_days / DAYS_IN_YEAR)


def _minimum(constants: WorkDeductionRules, *, fixed_term: bool) -> Decimal:
    """Return the lett. a) minimum of the contract, in cents.

    Art. 13 c. 1 lett. a) TUIR: 690 EUR, 1,380 EUR "per i rapporti di lavoro
    a tempo determinato".  An apprenticeship is "un contratto di lavoro a
    tempo indeterminato" (D.Lgs. 81/2015 art. 41 c. 1), so it takes the
    open-ended minimum.

    Returns:
        ``constants.minimum.fixed_term`` or ``constants.minimum.open_ended``.
    """
    floor = constants.minimum
    return money(floor.fixed_term if fixed_term else floor.open_ended)


def minimum_left_to_tax_return(
    gross_income: Decimal,
    eligible_work_days: int,
    *,
    constants: WorkDeductionRules,
    fixed_term: bool = False,
) -> Decimal:
    """Return the part of the lett. a) minimum the withholding leaves out.

    The withholding agent proportions the minimum to the days of work
    (:func:`work_income_deduction`); the tax return grants it whole, the
    deduction due being the larger of the amount for the days and the
    minimum (Allegato C to the 730/2026 instructions, par. 19.9.1).  The
    worker recovers the difference in the tax return, as code AN of the
    Certificazione Unica tells.

    Args:
        gross_income: Reddito complessivo of the withholding.
        eligible_work_days: Days of work in the tax year.
        constants: Versioned Art. 13 constants; the 2026 schedule when
            ``None``.
        fixed_term: Whether an employment of the year is fixed-term.

    Returns:
        The whole minimum less the deduction of the withholding when the
        income is in lett. a) and the minimum is larger, otherwise zero.
    """
    c = constants
    if not _ZERO < gross_income <= c.detr_lo or eligible_work_days <= 0:
        return _ZERO
    withheld = work_income_deduction(
        gross_income, eligible_work_days, constants=c, fixed_term=fixed_term
    )
    return max(_ZERO, _minimum(c, fixed_term=fixed_term) - withheld)


def work_income_deduction(
    gross_income: Decimal,
    eligible_work_days: int = DAYS_IN_YEAR,
    *,
    constants: WorkDeductionRules,
    fixed_term: bool = False,
) -> Decimal:
    """Compute the Art. 13 co. 1 TUIR work-income deduction.

    Implements the statutory piecewise formula (circolare AdE 4/E/2025, p. 6)
    with ratios truncated to four decimal places per Art. 13 co. 6 TUIR:

    - RC <= 15 000: EUR 1 955 (flat).
    - 15 000 < RC <= 28 000: 1910 + 1190 * trunc4((28000-RC)/13000).
    - 28 000 < RC <= 50 000: 1910 * trunc4((50000-RC)/22000).
    - RC > 50 000: zero.

    The full-year amount is proportioned to the days by :func:`for_days`,
    without truncating ``eligible_work_days / 365``.  Pass
    ``eligible_work_days=365`` (the default) for a full year.

    The EUR 65 increment of co. 1.1, when 25 000 < RC ≤ 35 000, is then
    added whole: "deve essere corrisposto [...] per intero nel corso
    dell'anno [...] senza effettuare alcun ragguaglio al periodo di lavoro
    nell'anno" (circolare AdE 4/E del 18 febbraio 2022, par. 1.2.1, p. 7,
    sha256 86178812120ac6a6ae2c47f278b8b38d7b6ad28da36e9eccbef23e6223160796,
    after circolare 15/E/2007 par. 1.5.1).  The payroll of the observed
    termination p25 applies it so, to the cent.

    Up to 15 000 the deduction is at least the minimum of lett. a), 690 EUR
    or 1 380 EUR for a fixed-term employment, proportioned to the days as
    the withholding agent applies it: for an employment shorter than the
    year "il sostituto deve ragguagliare anche la detrazione minima al
    periodo di lavoro" (Agenzia delle Entrate, istruzioni CU 2026, punto
    367, p. 33).  The larger of the two amounts for the days is due.  The
    tax return grants the minimum whole (Allegato C to the 730/2026
    instructions, par. 19.9.1): :func:`minimum_left_to_tax_return`.
    Without days of work no deduction is due (same paragraph: the days of
    rigo C5 must be filled).

    Args:
        gross_income: Reddito complessivo di riferimento (taxable income,
            i.e. RAL minus employee INPS contributions).
        eligible_work_days: Calendar days in the tax year for which the
            worker is employed.  Determines the pro-rata ratio applied to
            the full-year deduction amount.
        constants: Versioned Art. 13 statutory constants. Defaults to the
            2026 schedule when ``None``.
        fixed_term: Whether an employment of the year is fixed-term, which
            selects the minimum of lett. a).

    Returns:
        The applicable deduction, rounded to two decimal places.
    """
    c = constants
    if gross_income <= _ZERO or eligible_work_days <= 0:
        return _ZERO
    if gross_income <= c.detr_lo:
        return max(
            for_days(c.detr_flat, eligible_work_days),
            for_days(_minimum(c, fixed_term=fixed_term), eligible_work_days),
        )
    increment = (
        c.detr_increment if c.increment_lo < gross_income <= c.increment_hi else _ZERO
    )
    # Equivalent as `<`: the schedule is continuous at detr_mid (detr_a).
    if gross_income <= c.detr_mid:  # pragma: no mutate
        ratio = _trunc4((c.detr_mid - gross_income) / c.detr_b_span)
        full_year = c.detr_a + c.detr_b_coeff * ratio
    # Equivalent as `<`: the schedule is zero at detr_high.
    elif gross_income <= c.detr_high:  # pragma: no mutate
        ratio = _trunc4((c.detr_high - gross_income) / c.detr_c_span)
        full_year = c.detr_a * ratio
    else:
        return _ZERO
    return for_days(full_year, eligible_work_days) + increment
