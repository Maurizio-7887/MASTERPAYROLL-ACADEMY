"""Model limitations that concern one run.

The candidates are the engine limitations of the bundle and those the
simplification notes of the CCNL declare.  Each is matched against the
facts of the run: the CCNL, the competence date the rules were read at,
the contract type, level, category, run kind, seniority and employer
headcount of the request, the capabilities the capability report scopes as
applicable, and the engine limitations whose code path built the pay chain
or paid an event.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from ccnl_engine.assurance.ruleset.services import provisional_paths
from ccnl_engine.capability.results import CapabilityScope
from ccnl_engine.contribution.enam.services import enam_paths
from ccnl_engine.contribution.minimum_base.services import (
    minimum_base_paths,
)
from ccnl_engine.fund.contractual.rules import contractual_paths
from ccnl_engine.limitation.models import LimitationFacts
from ccnl_engine.pension_fund.decision.services import paid_month_paths
from ccnl_engine.personal_withholding.services import same_kind_paths
from ccnl_engine.seniority.services import seniority_months_at
from ccnl_engine.severance.relief.services import (
    tfr_compensation_paths,
)

if TYPE_CHECKING:
    from ccnl_engine.capability.results import CapabilityReport
    from ccnl_engine.event.total.handlers import _EventTotals
    from ccnl_engine.limitation.models import ModelLimitation
    from ccnl_engine.period.context.services import RunContext

__all__ = ["limitation_facts", "run_limitations"]


def limitation_facts(
    ctx: RunContext,
    report: CapabilityReport,
    traversed: frozenset[str] = frozenset(),
) -> LimitationFacts:
    """Return the facts of the run the limitation scopes are matched against.

    Returns:
        The facts of the run.
    """
    request = ctx.request
    category = ctx.worker_category
    return LimitationFacts(
        ccnl_id=ctx.contract.ccnl.meta.ccnl_id,
        as_of=ctx.contract.tctx.competence,
        contract_type=request.contract_type.type,
        level_code=ctx.contract.level.code,
        worker_category=None if category is None else str(category),
        run_kind=str(ctx.run_kind),
        seniority_months=seniority_months_at(
            request.seniority, ctx.contract.tctx.competence
        ),
        applicable=frozenset(
            feature
            for feature, scope in report.scope.items()
            if scope is CapabilityScope.APPLICABLE
        ),
        traversed=frozenset(ctx.chain.limitations) | traversed | contractual_paths(ctx),
        headcount=request.employer.headcount.value,
    )


def run_limitations(
    ctx: RunContext, report: CapabilityReport, events: _EventTotals
) -> tuple[ModelLimitation, ...]:
    """Return the limitations that concern the run, engine ones first.

    Args:
        ctx: Context of the run.
        report: Capability report of the run.
        events: Totals of the events of the run: the engine limitations
            whose path they took, besides those of the pay chain, and the
            INPS base they add (:func:`paid_month_paths`).

    Returns:
        The applicable limitations, each once.
    """
    traversed = (
        events.limitations
        | paid_month_paths(ctx, events.inps_base)
        | enam_paths(ctx)
        | provisional_paths(ctx)
        | tfr_compensation_paths(ctx)
        | minimum_base_paths(ctx)
        | same_kind_paths(ctx)
    )
    facts = limitation_facts(ctx, report, traversed)
    candidates = (*ctx.repo.load_engine_limitations(), *ctx.contract.ccnl.limitations)
    return tuple(
        limitation for limitation in candidates if limitation.applies_to(facts)
    )
